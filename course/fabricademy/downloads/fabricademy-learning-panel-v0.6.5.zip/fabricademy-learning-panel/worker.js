import { createRemoteStore } from './remote.js';
import { createUpdateStore } from './updates.js';
import { bilibiliIdentity } from './model.js';
import { createTabPanelController, panelContext } from './panel-scope.js';

const controller = createTabPanelController(chrome, []);
const store = createRemoteStore(chrome.storage.local);
const updates = createUpdateStore(chrome.storage.local);
const bindings = catalog => catalog.courses.filter(c => c.bilibili).map(c => ({ course_id: c.id, ...c.bilibili }));
const initialized = (async () => {
  const cached = await store.cached();
  // Restore valid mappings before examining existing tabs on a worker wake.
  if (cached) await controller.setBindings(bindings(cached), { configureTabs: false });
  await controller.initialize();
  return cached;
})();
const apply = async catalog => {
  await initialized;
  await controller.setBindings(bindings(catalog));
};
let refreshFlight;
function reportToPanel(sender, stage, detail = '') {
  if (!chrome.tabs.sendMessage) return;
  try {
    const url = new URL(sender.url);
    if (url.origin !== new URL(chrome.runtime.getURL('panel.html')).origin || url.pathname !== '/panel.html') return;
    const tabId = Number(url.searchParams.get('tabId'));
    const expected = { bvid: url.searchParams.get('bvid'), p: Number(url.searchParams.get('p')) };
    if (!url.searchParams.has('tabId') || !Number.isSafeInteger(tabId) || tabId < 0) return;
    void chrome.tabs.get(tabId).then(tab => {
      const actual = bilibiliIdentity(tab.pendingUrl || tab.url);
      if (!actual || actual.bvid !== expected.bvid || actual.p !== expected.p) return;
      return chrome.tabs.sendMessage(tabId, { type: 'fabricademy-panel-loading', state: 'phase', stage, detail, expected });
    }).catch(() => {});
  } catch { /* A diagnostic failure must never block course loading. */ }
}
function refresh(force = false) {
  if (refreshFlight) return refreshFlight;
  refreshFlight = (async () => {
    const catalog = await store.refresh(force); await apply(catalog);
    await chrome.action.setBadgeText({ text: '' });
    return catalog;
  })().finally(() => { refreshFlight = null; });
  return refreshFlight;
}
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (sender.id !== chrome.runtime.id || sender.tab || !['courses:get', 'courses:refresh', 'popup:check', 'updates:check'].includes(message?.type)) return;
  (async () => {
    try {
      if (message.type === 'updates:check') {
        // Only our two extension views may check program metadata. This does
        // not depend on course loading and cannot open or control a video.
        const page = sender.url?.split('?')[0];
        if (![chrome.runtime.getURL('popup.html'), chrome.runtime.getURL('panel.html')].includes(page)) {
          reply({ ok: false }); return;
        }
        reply(await updates.check(message.force === true)); return;
      }
      if (message.type === 'popup:check') {
        if (sender.url !== chrome.runtime.getURL('popup.html') || !Number.isInteger(message.tabId) || message.tabId < 0) {
          reply({ ok: false, error: '无效的页面请求' }); return;
        }
        await initialized;
        let tab = await chrome.tabs.get(message.tabId);
        if (!tab.active || !bilibiliIdentity(tab.pendingUrl || tab.url)) {
          reply({ ok: true, state: 'outside' }); return;
        }
        const catalog = message.refresh ? await refresh(true) : await store.cached() || await refresh();
        const context = await controller.prepare(message.tabId);
        tab = await chrome.tabs.get(message.tabId);
        if (!tab.active || !bilibiliIdentity(tab.pendingUrl || tab.url)) {
          reply({ ok: true, state: 'outside' }); return;
        }
        const course = context && panelContext(tab, bindings(catalog))?.path === context.path && catalog.courses.find(c => c.id === context.courseId);
        reply(course ? { ok: true, state: 'matched', context, title: course.title } : { ok: true, state: 'unmatched' });
        return;
      }
      const started = Date.now();
      reportToPanel(sender, 'worker-request');
      const cached = await store.cached(), cacheMs = Date.now() - started;
      const useCache = message.type !== 'courses:refresh' && !!cached;
      reportToPanel(sender, useCache ? 'cache-hit' : 'remote-start', `缓存读取 ${cacheMs}ms`);
      const catalog = useCache ? cached : await refresh(message.type === 'courses:refresh');
      reply({ ok: true, catalog, diagnostics: { source: useCache ? 'cache' : 'network', cache_ms: cacheMs, total_ms: Date.now() - started } });
    } catch (error) { reply({ ok: false, error: error.message }); }
  })();
  return true;
});
// Retry discovery on manual clicks. Never open a panel after asynchronous fetch.
chrome.action.onClicked.addListener(() => {
  void refresh().catch(() => chrome.action.setTitle({ title: '课程网站暂时不可用；联网后再次点击重试' }));
});
(async () => {
  const cached = await initialized;
  try { await refresh(); }
  catch {
    if (!cached) {
      await chrome.action.setBadgeText({ text: '!' });
      await chrome.action.setTitle({ title: '首次使用需联网加载课程；点击重试' });
    }
  }
})();
