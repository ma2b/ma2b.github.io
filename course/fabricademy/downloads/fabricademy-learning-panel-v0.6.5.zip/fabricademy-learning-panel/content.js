(() => {
  'use strict';
  const CHANNEL = 'fabricademy-study-media-v1';
  const pending = new Map();
  let notice, slowTimer, stopTimer, diagnostic;
  function clearNotice() {
    clearTimeout(slowTimer); clearTimeout(stopTimer);
    notice?.remove(); notice = null; diagnostic = null;
  }
  function loadingNotice(message) {
    const match = location.pathname.match(/^\/video\/(BV[0-9A-Za-z]{10})\/?$/);
    if (!match || message.expected?.bvid !== match[1]
      || message.expected.p !== Number(new URL(location.href).searchParams.get('p') || 1)) return;
    if (message.state === 'ready') { clearNotice(); return; }
    if (message.state === 'phase') { diagnostic?.record(message.stage, message.detail); return; }
    if (message.state === 'error' && diagnostic) { diagnostic.fail(message.detail); return; }
    if (!['loading', 'error'].includes(message.state)) return;
    clearNotice();
    const host = document.createElement('div');
    host.style.cssText = 'position:fixed;top:76px;right:20px;z-index:2147483647;width:290px;max-width:calc(100vw - 40px)';
    const root = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = ':host{all:initial}section{font:13px/1.6 system-ui,sans-serif;color:#25382f;background:#f5f6f2;border:1px solid #d7dfd4;border-radius:10px;padding:12px;box-shadow:0 4px 20px #0002}strong{display:block}p{margin:5px 0}button{float:right;cursor:pointer;border:0;background:none;color:#61736a;font-size:18px}a{color:#276a4b;font-size:12px}.track{height:3px;background:#d7dfd4;overflow:hidden;border-radius:3px;margin-top:8px}.track span{display:block;width:34%;height:100%;background:#276a4b;animation:move 1.4s ease-in-out infinite alternate}@keyframes move{to{transform:translateX(195%)}}[hidden]{display:none!important}@media(prefers-reduced-motion:reduce){.track span{animation:none;width:100%}}';
    const box = document.createElement('section'); box.setAttribute('role', 'status');
    const close = document.createElement('button'); close.textContent = '×'; close.setAttribute('aria-label', '关闭加载提示');
    close.addEventListener('click', clearNotice);
    const heading = document.createElement('strong'); heading.textContent = 'Fabricademy · 正在打开学习面板';
    const detail = document.createElement('p'); detail.textContent = '等待 Chrome 打开侧栏…';
    const link = document.createElement('a'); link.textContent = '也可打开课程主页 ↗';
    link.href = 'https://ma2b.github.io/course/fabricademy/'; link.target = '_blank'; link.rel = 'noopener noreferrer';
    const track = document.createElement('div'); track.className = 'track';
    track.setAttribute('role', 'progressbar'); track.setAttribute('aria-label', '学习面板加载中'); track.append(document.createElement('span'));
    const details = document.createElement('details'), summary = document.createElement('summary');
    summary.textContent = '查看加载诊断';
    const log = document.createElement('textarea'); log.readOnly = true; log.rows = 8;
    log.setAttribute('aria-label', '加载诊断记录');
    log.style.cssText = 'box-sizing:border-box;width:100%;margin-top:6px;font:11px/1.5 monospace;resize:vertical';
    details.append(summary, log);
    box.append(close, heading, detail, track, details, link); root.append(style, box);
    notice = host; document.documentElement.append(host);
    const labels = {
      clicked: '已收到打开请求', opened: 'Chrome 已接受打开侧栏请求',
      'panel-script': '侧栏主脚本已执行', 'document-loaded': '侧栏页面已加载',
      'courses-request': '正在请求课程数据', 'worker-request': '后台收到课程请求，正在读取缓存',
      'cache-hit': '课程缓存可用', 'remote-start': '无可用缓存，正在下载课程',
      'courses-received': '侧栏已收到课程数据', preferences: '正在读取窗口与外观设置',
      render: '正在准备笔记', 'notes-ready': '笔记内容已准备',
      'panel-visible': '侧栏可见', 'panel-reused': '复用已有侧栏页面',
      'player-request': '正在连接播放器', 'player-ready': '播放器已连接',
      'player-error': '播放器连接未完成', slow: '等待较久', error: '启动失败'
    };
    const started = performance.now(), lines = [`插件 v${chrome.runtime.getManifest?.().version || '未知'} · ${match[1]} · P${message.expected.p}`];
    let last = labels.clicked;
    let progress = '等待 Chrome 打开侧栏';
    const phases = {
      clicked: '等待 Chrome 打开侧栏', opened: '等待侧栏主脚本启动',
      'panel-script': '等待侧栏页面加载', 'document-loaded': '正在启动学习面板',
      'courses-request': '等待后台返回课程', 'worker-request': '正在读取课程缓存',
      'cache-hit': '正在接收缓存课程', 'remote-start': '正在下载课程',
      'courses-received': '正在准备课程笔记', preferences: '正在读取外观设置', render: '正在准备笔记',
      'notes-ready': '笔记内容已准备，等待侧栏显示', 'panel-reused': '等待已有侧栏显示',
      'panel-visible': '侧栏可见'
    };
    function record(stage, extra) {
      if (!labels[stage]) return;
      if (stage !== 'slow') last = labels[stage];
      if (phases[stage]) progress = phases[stage];
      const safe = typeof extra === 'string' ? extra.replace(/[\r\n]/g, ' ').slice(0, 200) : '';
      lines.push(`${((performance.now() - started) / 1000).toFixed(1)}s ${labels[stage]}${safe ? '：' + safe : ''}`);
      if (lines.length > 30) lines.splice(1, 1);
      log.value = lines.join('\n'); detail.textContent = progress + '…';
    }
    const failed = extra => {
      clearTimeout(slowTimer); clearTimeout(stopTimer);
      const stalled = last;
      if (typeof extra === 'string' && extra) record('error', extra);
      heading.textContent = '学习面板尚未就绪';
      detail.textContent = `最后阶段：${stalled}。展开诊断可查看经过时间与错误。`;
      track.hidden = true; details.open = true;
    };
    diagnostic = { record, fail: failed }; record('clicked');
    if (message.state === 'error') failed(message.detail);
    else {
      slowTimer = setTimeout(() => { detail.textContent = `加载比平时慢：${progress}…`; }, 8000);
      stopTimer = setTimeout(() => {
        // This is a watchdog observation, not a rejected open/boot request.
        // Chrome can still respond later; keep feedback and progress alive.
        record('slow', '25 秒内未收到笔记就绪回报，继续等待');
        heading.textContent = '学习面板加载较慢';
        detail.textContent = `${progress}；已等待 25 秒，将继续等待。`;
        details.open = true;
      }, 25000);
    }
  }
  window.addEventListener('pagehide', clearNotice);
  window.addEventListener('popstate', clearNotice);
  window.addEventListener('message', event => {
    const m = event.data;
    if (event.source !== window || event.origin !== location.origin || m?.channel !== CHANNEL || m.kind !== 'response') return;
    const entry = pending.get(m.requestId);
    if (!entry) return;
    clearTimeout(entry.timer); pending.delete(m.requestId); entry.reply(m.result);
  });
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id === chrome.runtime.id && message?.type === 'fabricademy-panel-loading') {
      loadingNotice(message); reply({ ok: true }); return;
    }
    if (sender.id !== chrome.runtime.id || message?.type !== 'fabricademy-media' || !['state', 'seek', 'pause', 'play'].includes(message.command)) return;
    const requestId = crypto.randomUUID();
    const timer = setTimeout(() => {
      pending.delete(requestId); reply({ ok: false, error: '无法连接 B站播放器，请刷新视频页面后重试' });
    }, 4000);
    pending.set(requestId, { reply, timer });
    window.postMessage({ channel: CHANNEL, kind: 'request', requestId,
      command: message.command, expected: message.expected, time: message.time }, location.origin);
    return true;
  });
})();
