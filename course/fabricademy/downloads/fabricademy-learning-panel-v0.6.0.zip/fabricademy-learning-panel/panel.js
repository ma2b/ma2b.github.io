import { clock, bilibiliIdentity, sameVideo, chapterAt, validateCatalog } from './model.js';

const api = globalThis.chrome?.runtime?.id ? chrome : null;
const $ = id => document.getElementById(id);
const state = { catalog: null, course: null, chapter: null, tab: null,
  owner: null, video: null, media: null, windowId: null, timer: null, polling: false, controlling: false, syncing: false };

function readOwner() {
  const query = new URLSearchParams(location.search), id = query.get('tabId');
  if (!id || !/^\d+$/.test(id) || !Number.isSafeInteger(Number(id))) return null;
  const course = state.catalog.courses.find(c => c.id === query.get('courseId'));
  const video = { bvid: query.get('bvid'), p: Number(query.get('p')) };
  return sameVideo(course?.bilibili, video) ? { tabId: Number(id), courseId: course.id, video } : null;
}
function ownsTab(tab) {
  return state.owner && tab?.id === state.owner.tabId && tab.active
    && sameVideo(bilibiliIdentity(tab.pendingUrl || tab.url), state.owner.video)
    && sameVideo(state.catalog.courses.find(c => c.id === state.owner.courseId)?.bilibili, state.owner.video);
}

function element(tag, text, className) {
  const el = document.createElement(tag);
  if (text !== undefined) el.textContent = text;
  if (className) el.className = className;
  return el;
}
function button(text, action, className) {
  const el = element('button', text, className); el.type = 'button'; el.addEventListener('click', action); return el;
}
function message(text) { $('status').textContent = text; }
function asset(src) { return globalThis.__STUDY_PREVIEW__ && src.startsWith('assets/') ? 'extension/' + src : src; }
function setImage(img, frame) {
  img.src = asset(frame.src); img.alt = frame.caption;
  img.addEventListener('error', () => {
    if (frame.fallback_src && img.dataset.fallback !== 'true') { img.dataset.fallback = 'true'; img.src = asset(frame.fallback_src); }
    else img.alt = `图片暂时不可用：${frame.caption}`;
  });
}
function canControl() {
  const mapping = state.course?.bilibili;
  return api && !document.hidden && ownsTab(state.tab) && state.course.id === state.owner.courseId
    && sameVideo(mapping, state.video) && state.media?.ready
    && Math.abs(state.media.duration - state.course.duration - mapping.offset_seconds) <= Math.max(8, state.course.duration * .005);
}
function playingChapter() {
  return canControl()
    ? chapterAt(state.course, state.media.currentTime - state.course.bilibili.offset_seconds) : null;
}
function timeButton(time, label = `▶ ${clock(time)}`) {
  const el = button(label, () => control('seek', time), 'time-button');
  el.dataset.seek = String(time); el.title = `从 ${clock(time)} 播放视频`;
  el.disabled = !canControl() || state.controlling;
  return el;
}
function renderCourseOptions() {
  $('course').replaceChildren(...state.catalog.courses.map(c => {
    const option = element('option', c.title); option.value = c.id; return option;
  }));
}
function selectCourse(id, chapterId) {
  state.course = state.catalog.courses.find(c => c.id === id) || state.catalog.courses[0];
  state.chapter = state.course.chapters.find(c => c.id === chapterId) || state.course.chapters[0];
  $('course').value = state.course.id;
  $('course-meta').textContent = `${state.course.chapters.length} 章 · ${clock(state.course.duration)}`;
  $('course-page').href = state.course.page_url;
  $('search').value = '';
  renderDirectory(); renderChapter(); renderConnection();
  $('reading-pane').scrollTop = 0; $('chapter-list').scrollTop = 0;
}
function selectChapter(id, scroll = true) {
  state.chapter = state.course.chapters.find(c => c.id === id) || state.course.chapters[0];
  renderChapter(); markDirectory();
  if (scroll) $('reading-pane').scrollTop = 0;
}
function renderDirectory() {
  const query = $('search').value.trim().toLocaleLowerCase();
  $('chapter-count').textContent = `${state.course.chapters.length} 章`;
  const rows = state.course.chapters.flatMap((c, i) => {
    const haystack = [c.title, c.summary, ...c.key_points, ...c.actions, ...c.terms.flatMap(t => [t.term, t.definition]), ...c.moments.map(m => m.title)].join(' ').toLocaleLowerCase();
    if (query && !haystack.includes(query)) return [];
    const row = element('div', undefined, 'chapter-row'); row.dataset.chapterId = c.id;
    const title = button(`${String(i + 1).padStart(2, '0')}. ${c.title}`, () => selectChapter(c.id), 'chapter-link');
    title.setAttribute('aria-controls', `moments-${c.id}`);
    const list = element('ol', undefined, 'chapter-subsections'); list.id = `moments-${c.id}`;
    list.setAttribute('aria-label', `${c.title}的时间点`);
    const start = element('li'); start.append(timeButton(c.start, `▶ ${clock(c.start)} · 本章开始`)); list.append(start);
    for (const m of c.moments) {
      const li = element('li'), heading = element('h3', undefined, 'moment-heading');
      const seek = timeButton(m.time); seek.replaceChildren(element('span', `▶ ${clock(m.time)}`, 'moment-time'), element('span', m.title, 'moment-title'));
      seek.setAttribute('aria-label', `从 ${clock(m.time)} 播放：${m.title}`);
      heading.append(seek); li.append(heading); list.append(li);
    }
    row.append(title, list); return [row];
  });
  $('chapter-list').replaceChildren(...(rows.length ? rows : [element('p', '没有匹配章节，换一个关键词试试。', 'hint')]));
  markDirectory();
}
function markDirectory() {
  const playing = playingChapter()?.id;
  for (const row of document.querySelectorAll('.chapter-row')) {
    const reading = row.dataset.chapterId === state.chapter.id;
    row.classList.toggle('reading', reading); row.classList.toggle('playing', row.dataset.chapterId === playing);
    const showTimes = reading || !!$('search').value.trim();
    row.querySelector('.chapter-subsections').hidden = !showTimes;
    row.firstChild.setAttribute('aria-expanded', String(showTimes));
    if (reading) row.firstChild.setAttribute('aria-current', 'true'); else row.firstChild.removeAttribute('aria-current');
  }
}
function renderChapter() {
  const c = state.chapter, index = state.course.chapters.indexOf(c), article = $('chapter');
  const kicker = element('div', undefined, 'chapter-kicker');
  kicker.append(element('span', '课程详情'), element('span', `CHAPTER ${String(index + 1).padStart(2, '0')}`));
  article.replaceChildren(kicker, element('h1', c.title), element('p', `${clock(c.start)} — ${clock(c.end)}`, 'chapter-range'), element('h2', '本章摘要'), element('p', c.summary, 'summary'));
  for (const f of c.frames) {
    const figure = element('figure', undefined, 'frame'), img = element('img');
    img.loading = 'lazy'; setImage(img, f);
    const enlarge = button('', () => {
      $('large-image').removeAttribute('data-fallback');
      $('large-image').src = img.src; $('large-image').alt = f.caption;
      $('large-caption').textContent = `${clock(f.time)} · ${f.caption}`;
      $('image-dialog').showModal();
    }, 'image-button');
    enlarge.setAttribute('aria-label', `放大图片：${f.caption}`); enlarge.append(img);
    const caption = element('figcaption'); caption.append(timeButton(f.time, clock(f.time)), document.createTextNode(` · ${f.caption}`));
    figure.append(enlarge, caption); article.append(figure);
  }
  if (c.key_points.length) {
    const list = element('ul', undefined, 'points'); list.append(...c.key_points.map(p => element('li', p)));
    article.append(element('h2', '关键观点'), list);
  }
  if (c.terms.length) {
    const list = element('dl', undefined, 'terms');
    for (const t of c.terms) { const item = element('div'); item.append(element('dt', t.term), element('dd', t.definition)); list.append(item); }
    article.append(element('h2', '术语速查'), list);
  }
  if (c.actions.length) {
    const list = element('ol', undefined, 'actions'); list.append(...c.actions.map(a => element('li', a)));
    article.append(element('h2', '行动清单'), list);
  }
  if (c.references.length) {
    const list = element('ul', undefined, 'points');
    for (const r of c.references) {
      const li = element('li'), a = element('a', r.title); a.href = r.url; a.target = '_blank'; a.rel = 'noopener noreferrer'; li.append(a); list.append(li);
    }
    article.append(element('h2', '核对资料'), list);
  }
  $('previous').disabled = index === 0; $('next').disabled = index === state.course.chapters.length - 1;
  $('reading-position').textContent = `${index + 1} / ${state.course.chapters.length}`;
}
function renderConnection() {
  const mapping = state.course?.bilibili, connected = canControl();
  $('open-video').hidden = !mapping || sameVideo(mapping, state.video);
  $('toggle-play').disabled = !connected || state.controlling;
  $('toggle-play').textContent = state.media?.paused ? '继续播放' : '暂停精读';
  $('follow-video').disabled = !playingChapter();
  $('connection-dot').classList.toggle('connected', !!connected);
  $('playback-time').textContent = connected ? clock(state.media.currentTime - mapping.offset_seconds) : '--:--';
  let title, detail;
  if (!api) { title = '界面预览'; detail = '这是四门课程的真实 AI 笔记。请加载扩展后连接 B站播放器。'; }
  else if (!state.owner) { title = '请重新打开学习面板'; detail = '请关闭此面板，在已绑定的 B站视频标签页中点击插件图标。'; }
  else if (!mapping) { title = '课程笔记已就绪'; detail = '这门课尚未绑定 B站视频，当前可以阅读全部 AI 内容。'; }
  else if (!ownsTab(state.tab) || state.course.id !== state.owner.courseId || !sameVideo(mapping, state.video)) { title = '等待对应视频'; detail = `请在 ${mapping.bvid} · P${mapping.p} 的标签页手动打开插件。每个面板只连接打开它的视频标签页。`; }
  else if (!state.media?.ready) { title = '等待播放器就绪'; detail = '请先在 B站点击播放。首次安装或重新加载扩展后，请刷新视频页面。'; }
  else if (!connected) { title = '视频时间轴不匹配'; detail = `课程 ${clock(state.course.duration)}，视频 ${clock(state.media.duration)}。暂不启用定位，请确认上传版本。`; }
  else { title = state.media.paused ? '已连接 · 已暂停' : '已连接 · 正在播放'; detail = playingChapter() ? `视频所在：${playingChapter().title}` : '播放器已连接，可按时间点学习。'; }
  $('connection-title').textContent = title; $('connection-detail').textContent = detail;
  for (const el of document.querySelectorAll('button[data-seek]')) el.disabled = !connected || state.controlling;
  markDirectory();
}

async function ownerTab() {
  if (!state.owner) return null;
  try { return await api.tabs.get(state.owner.tabId); } catch { return null; }
}
function updateTimer() {
  const run = api && !document.hidden && ownsTab(state.tab);
  if (!run && state.timer !== null) { clearInterval(state.timer); state.timer = null; }
  if (run && state.timer === null) state.timer = setInterval(poll, 1200);
}
async function poll() {
  if (!api || !state.owner || state.polling || document.hidden) return;
  state.polling = true;
  try {
    const tab = await ownerTab(), video = bilibiliIdentity(tab?.pendingUrl || tab?.url);
    state.tab = tab; state.video = video; state.windowId = tab?.windowId ?? state.windowId;
    if (!ownsTab(tab) || document.hidden) state.media = null;
    else {
      let response;
      try { response = await api.tabs.sendMessage(tab.id, { type: 'fabricademy-media', command: 'state' }); } catch { response = null; }
      const current = await ownerTab(); state.tab = current;
      if (!ownsTab(current) || document.hidden) { state.media = null; return; }
      state.media = response?.ok && sameVideo(response.state, video) ? response.state : null;
    }
  } catch { state.tab = null; state.media = null; }
  finally { state.polling = false; updateTimer(); renderConnection(); }
}
async function control(command, time) {
  if (!canControl() || state.controlling) return;
  const course = state.course, tabId = state.tab.id;
  state.controlling = true; renderConnection(); message('');
  try {
    const current = await ownerTab(); state.tab = current;
    if (!ownsTab(current) || document.hidden || state.course.id !== course.id) throw new Error('面板所属视频已切换或隐藏，请返回对应标签页');
    const result = await api.tabs.sendMessage(tabId, { type: 'fabricademy-media', command,
      time: time === undefined ? undefined : time + course.bilibili.offset_seconds,
      expected: { ...course.bilibili, duration: course.duration + course.bilibili.offset_seconds } });
    const now = await ownerTab(); state.tab = now;
    if (!ownsTab(now) || document.hidden || state.course.id !== course.id) { state.media = null; return; }
    if (!result?.ok) throw new Error(result?.error || '播放器没有回应，请刷新 B站页面');
    if (!sameVideo(result.state, state.owner.video)) throw new Error('视频已改变，请返回对应视频后重试');
    state.media = result.state;
    message(result.warning || (command === 'seek' ? `已定位至 ${clock(result.state.currentTime - course.bilibili.offset_seconds)}` : command === 'pause' ? '视频已暂停，可以继续阅读。' : '已请求继续播放。'));
  } catch (error) { state.media = null; message(error.message); }
  finally { state.controlling = false; updateTimer(); renderConnection(); }
}
function renderVersion() {
  $('content-version').textContent = `GitHub 课程数据 · ${state.catalog.courses.length} 门 · ${state.catalog.revision.slice(0, 8)}`;
}
async function sync() {
  if (!api || state.syncing) return;
  state.syncing = true; $('sync').disabled = true; $('sync').textContent = '正在检查…'; message('');
  try {
    const reply = await api.runtime.sendMessage({ type: 'courses:refresh' });
    if (!reply?.ok) throw new Error(reply?.error || '课程后台没有回应');
    const next = validateCatalog(reply.catalog);
    const id = state.course.id, chapterId = state.chapter.id;
    state.catalog = next; renderCourseOptions(); selectCourse(id, chapterId); renderVersion();
    message('已从 GitHub 更新课程目录与 AI 笔记。新增课程无需重新安装插件。');
    await poll();
  } catch (error) { message(`更新未完成，保留现有内容。${error.message}`); }
  finally { state.syncing = false; $('sync').disabled = false; $('sync').textContent = '更新课程内容'; }
}
async function boot() {
  let data = globalThis.__STUDY_PREVIEW__;
  if (api) {
    const reply = await api.runtime.sendMessage({ type: 'courses:get' });
    if (!reply?.ok) throw new Error(reply?.error || '首次使用需要联网获取课程');
    data = reply.catalog;
    state.windowId = (await api.windows.getCurrent()).id;
    try {
      const stored = await api.storage.local.get('fabricademy-panel-theme');
      const theme = stored['fabricademy-panel-theme'];
      if (['light', 'mid', 'dark'].includes(theme)) { document.documentElement.dataset.theme = theme; $('theme').value = theme; }
    } catch { message('外观偏好无法读取。'); }
  } else { $('preview-notice').hidden = false; $('sync').disabled = true; }
  state.catalog = validateCatalog(data);
  if (api) state.owner = readOwner();
  renderCourseOptions(); selectCourse(state.owner?.courseId || state.catalog.courses.find(c => c.bilibili)?.id); renderVersion();
  $('course').addEventListener('change', () => { message(''); selectCourse($('course').value); });
  $('search').addEventListener('input', renderDirectory);
  $('position-help-toggle').addEventListener('click', () => {
    const open = $('position-help').hidden;
    $('position-help').hidden = !open;
    $('position-help-toggle').setAttribute('aria-expanded', String(open));
  });
  $('previous').addEventListener('click', () => selectChapter(state.course.chapters[state.course.chapters.indexOf(state.chapter) - 1].id));
  $('next').addEventListener('click', () => selectChapter(state.course.chapters[state.course.chapters.indexOf(state.chapter) + 1].id));
  $('follow-video').addEventListener('click', () => { const chapter = playingChapter(); if (chapter) selectChapter(chapter.id); });
  $('toggle-play').addEventListener('click', () => control(state.media?.paused ? 'play' : 'pause'));
  $('open-video').addEventListener('click', () => {
    if (!state.course.bilibili) return;
    const { bvid, p } = state.course.bilibili, url = `https://www.bilibili.com/video/${bvid}/?p=${p}`;
    if (api) api.tabs.create({ url, windowId: state.windowId }).catch(error => message(error.message));
    else window.open(url, '_blank', 'noopener,noreferrer');
  });
  $('theme').addEventListener('change', async () => {
    const value = $('theme').value; document.documentElement.dataset.theme = value;
    if (api) try { await api.storage.local.set({ 'fabricademy-panel-theme': value }); } catch { message('外观已切换，但未能保存偏好。'); }
  });
  $('close-image').addEventListener('click', () => $('image-dialog').close());
  $('sync').addEventListener('click', sync);
  await poll();
  if (api && state.owner) {
    document.addEventListener('visibilitychange', () => { updateTimer(); renderConnection(); void poll(); });
    api.tabs.onActivated.addListener(({ tabId, windowId }) => {
      if (tabId === state.owner.tabId || windowId === state.windowId) void poll();
    });
    api.tabs.onUpdated.addListener((id, change) => { if (id === state.owner.tabId && (change.url || change.status)) void poll(); });
    api.tabs.onRemoved.addListener(id => {
      if (id === state.owner.tabId) { state.tab = null; state.media = null; updateTimer(); renderConnection(); }
    });
    window.addEventListener('pagehide', () => { if (state.timer !== null) clearInterval(state.timer); state.timer = null; });
  }
}
boot().catch(error => message(`学习面板未能启动：${error.message}`));
