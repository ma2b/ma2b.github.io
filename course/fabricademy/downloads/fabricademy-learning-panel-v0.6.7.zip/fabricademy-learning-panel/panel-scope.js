import { bilibiliIdentity, sameVideo } from './model.js';

export function panelContext(tab, bindings) {
  if (!Number.isInteger(tab?.id) || tab.id < 0) return null;
  const video = bilibiliIdentity(tab.pendingUrl || tab.url);
  const binding = video && bindings.find(b => sameVideo(b, video));
  if (!binding) return null;
  const query = new URLSearchParams({ tabId: String(tab.id), courseId: binding.course_id, bvid: video.bvid, p: String(video.p) });
  return { tabId: tab.id, path: `panel.html?${query}`, video, courseId: binding.course_id };
}

// Configure availability on browser events. Chrome handles clicks on prepared
// tabs directly, even while the worker sleeps. Only explicit user gestures can
// open; assigning a tab-specific path never requests that it be shown.
export function createTabPanelController(api, initialBindings) {
  let bindings = initialBindings;
  let bindingsReady = initialBindings.length > 0;
  const bindingKey = list => JSON.stringify(list.map(b => [b.course_id, b.bvid, b.p]).sort());
  let currentBindingsKey = bindingKey(bindings);
  let initialization;
  const queues = new Map(), epochs = new Map(), known = new Map();
  const title = '打开 Fabricademy 学习面板';
  const ignore = promise => Promise.resolve(promise).catch(() => {});
  function hint(tabId, text, badge = '') {
    ignore(api.action.setTitle({ tabId, title: text }));
    ignore(api.action.setBadgeText({ tabId, text: badge }));
  }
  function loading(context, state, stage, detail) {
    if (api.tabs.sendMessage) ignore(api.tabs.sendMessage(context.tabId, {
      type: 'fabricademy-panel-loading', state, stage, detail, expected: context.video
    }));
  }
  function configure(tab, { invalidatePending = false } = {}) {
    if (!Number.isInteger(tab?.id) || tab.id < 0) return Promise.resolve();
    // An empty in-memory map on worker wake is not a validated empty catalogue.
    // initialize() scans the latest tabs after the cache has been examined.
    if (!bindingsReady && !invalidatePending) return Promise.resolve();
    const id = tab.id, epoch = (epochs.get(id) || 0) + 1;
    epochs.set(id, epoch);
    const job = (queues.get(id) || Promise.resolve()).catch(() => {}).then(async () => {
      if (epochs.get(id) !== epoch) return;
      const context = panelContext(tab, bindings);
      const target = context?.path || null;
      // Read Chrome's actual options: a previous queued write may have finished
      // after navigation invalidated its result, so the hint cache can be stale.
      const current = await api.sidePanel.getOptions({ tabId: id });
      if (epochs.get(id) !== epoch) return;
      if (!context) {
        if (current.enabled !== false) await api.sidePanel.setOptions({ tabId: id, enabled: false });
        if (epochs.get(id) === epoch) {
          await api.action.setPopup({ tabId: id, popup: 'popup.html' });
          if (epochs.get(id) === epoch) { known.set(id, { enabled: false }); hint(id, '查看课程使用提示'); }
        }
        return;
      }
      if (!current.enabled || current.path !== target) {
        // Close an old video's panel before assigning another course in this tab.
        if (current.enabled) await api.sidePanel.setOptions({ tabId: id, enabled: false });
        if (epochs.get(id) !== epoch) return;
        await api.sidePanel.setOptions({ tabId: id, path: target, enabled: true });
      }
      if (epochs.get(id) === epoch) {
        await api.action.setPopup({ tabId: id, popup: '' });
        if (epochs.get(id) === epoch) { known.set(id, { path: target, enabled: true }); hint(id, title); }
      }
    }).catch(() => { known.delete(id); }); // Closed tabs are normal, not an error popup.
    queues.set(id, job);
    job.finally(() => { if (queues.get(id) === job) queues.delete(id); });
    return job;
  }
  async function refresh(tabId) {
    try { return await configure(await api.tabs.get(tabId)); } catch { known.delete(tabId); }
  }
  async function refreshCourseTabs() {
    const tabs = await api.tabs.query({ url: 'https://www.bilibili.com/video/*' });
    await Promise.all(tabs.map(tab => configure(tab)));
  }
  function clicked(tab) {
    // Fallback for a click before Chrome's native toolbar behavior is enabled.
    // Prepared tabs normally bypass this event entirely (Chromium RunAction).
    const context = panelContext(tab, bindings);
    if (!context) {
      if (Number.isInteger(tab?.id)) {
        hint(tab.id, '当前页面没有匹配的课程视频，学习面板未打开', '—');
        void configure(tab);
      }
      return;
    }
    // Do not await tab queries/storage/setOptions before open: asynchronous work
    // can lose Chrome's user gesture. The tab path is prepared on navigation.
    // There is no global manifest path, so an unprepared tab fails closed.
    const prepared = known.get(tab.id);
    if (prepared && (!prepared.enabled || prepared.path !== context.path)) {
      void configure(tab).then(() => hint(tab.id, '课程面板已准备，请再点击插件打开', '↻'));
      return;
    }
    // Open synchronously to retain the click gesture, but show feedback in the
    // video page as well: Chrome can keep the side-panel document hidden on load.
    hint(tab.id, '正在打开学习面板…', '…');
    loading(context, 'loading');
    const openStarted = performance.now();
    api.sidePanel.open({ tabId: context.tabId }).then(() => {
      loading(context, 'phase', 'opened', `打开接口回报用时 ${Math.round(performance.now() - openStarted)}ms`);
      hint(tab.id, title);
      // A previously loaded panel may be reused without running boot again.
      if (api.runtime?.sendMessage) ignore(api.runtime.sendMessage({
        type: 'panel:ping', tabId: context.tabId, courseId: context.courseId
      }).then(reply => { if (reply?.ready) loading(context, 'ready'); }));
    }).catch(error => {
      loading(context, 'error', 'error', String(error.message || error).slice(0, 200));
      void configure(tab).then(() => hint(tab.id, '面板尚未就绪，请再次点击插件；必要时刷新视频页', '↻'));
    });
  }
  api.action.onClicked.addListener(clicked);
  api.tabs.onUpdated.addListener((tabId, change, tab) => {
    if (change.url || change.status === 'loading' || change.status === 'complete') {
      void configure({ ...tab, id: tabId, ...(change.url ? { url: change.url, pendingUrl: undefined } : {}) },
        { invalidatePending: !!change.url || change.status === 'loading' });
    }
  });
  api.tabs.onActivated.addListener(({ tabId }) => { void refresh(tabId); });
  api.tabs.onRemoved.addListener(tabId => {
    epochs.set(tabId, (epochs.get(tabId) || 0) + 1); known.delete(tabId);
    // Do not keep a map entry per visited page once a tab has closed.
    const job = queues.get(tabId);
    if (job) job.finally(() => { if (!queues.has(tabId)) epochs.delete(tabId); });
    else epochs.delete(tabId);
  });
  return {
    initialize() {
      if (!initialization) initialization = (async () => {
        bindingsReady = true;
        await api.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
        await api.sidePanel.setOptions({ enabled: false });
        await api.action.setPopup({ popup: 'popup.html' });
        await refreshCourseTabs();
      })().catch(() => { initialization = null; });
      return initialization;
    },
    async prepare(tabId) {
      await refresh(tabId);
      const tab = await api.tabs.get(tabId);
      const context = panelContext(tab, bindings);
      const options = await api.sidePanel.getOptions({ tabId });
      return context && tab.active && options.enabled && options.path === context.path ? context : null;
    },
    async setBindings(next, { configureTabs = true } = {}) {
      bindingsReady = true;
      const nextKey = bindingKey(next);
      if (nextKey === currentBindingsKey) return;
      bindings = next; currentBindingsKey = nextKey; known.clear();
      if (configureTabs) await refreshCourseTabs();
    },
    async idle() { await Promise.all([...queues.values()]); }
  };
}
