import { createRemoteStore } from './remote.js';
import { createTabPanelController } from './panel-scope.js';

const controller = createTabPanelController(chrome, []);
const store = createRemoteStore(chrome.storage.local);
const bindings = catalog => catalog.courses.filter(c => c.bilibili).map(c => ({ course_id: c.id, ...c.bilibili }));
const initialized = (async () => {
  const cached = await store.cached();
  // Restore valid mappings before examining existing tabs on a worker wake.
  if (cached) await controller.setBindings(bindings(cached));
  await controller.initialize();
  return cached;
})();
const apply = async catalog => {
  await initialized;
  await controller.setBindings(bindings(catalog));
};
let refreshFlight;
function refresh(force = false) {
  if (refreshFlight) return refreshFlight;
  refreshFlight = (async () => {
    const catalog = await store.refresh(force); await apply(catalog);
    await chrome.action.setBadgeText({ text: '' });
    return catalog;
  })().finally(() => { refreshFlight = null; });
  return refreshFlight;
}
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (sender.id !== chrome.runtime.id || sender.tab || !['courses:get', 'courses:refresh'].includes(message?.type)) return;
  (async () => {
    try {
      const catalog = message.type === 'courses:refresh' ? await refresh(true) : await store.cached() || await refresh();
      reply({ ok: true, catalog });
    } catch (error) { reply({ ok: false, error: error.message }); }
  })();
  return true;
});
// Retry discovery on manual clicks. Never open a panel after asynchronous fetch.
chrome.action.onClicked.addListener(() => {
  void refresh(true).catch(() => chrome.action.setTitle({ title: '课程网站暂时不可用；联网后再次点击重试' }));
});
(async () => {
  const cached = await initialized;
  try { await refresh(); }
  catch {
    if (!cached) {
      await chrome.action.setBadgeText({ text: '!' });
      await chrome.action.setTitle({ title: '首次使用需联网加载课程；点击重试' });
    }
  }
})();
