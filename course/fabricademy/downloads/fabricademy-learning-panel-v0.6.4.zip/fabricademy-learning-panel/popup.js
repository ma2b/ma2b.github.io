export function createPopup(api, doc, close = () => window.close()) {
  const $ = id => doc.getElementById(id);
  let tabId, windowId, context = null, epoch = 0, disposed = false;
  function show(title, detail, busy = false) {
    $('heading').textContent = title; $('detail').textContent = detail;
    $('message').setAttribute('aria-busy', String(busy));
    $('retry').disabled = busy; $('retry').textContent = busy ? '正在检查…' : '重新检查课程';
    $('open-panel').hidden = !context; $('open-panel').disabled = busy;
  }
  async function check(refresh = false) {
    const ticket = ++epoch; context = null;
    show('正在检查课程…', '正在确认当前视频是否有对应的学习笔记。', true);
    let timer;
    try {
      if (!Number.isInteger(tabId)) throw new Error('No tab');
      const reply = await Promise.race([
        api.runtime.sendMessage({ type: 'popup:check', tabId, refresh }),
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('Timeout')), 25000); })
      ]);
      if (disposed || ticket !== epoch) return;
      if (!reply?.ok) throw new Error('Unavailable');
      if (reply.state === 'matched' && reply.context?.tabId === tabId) {
        context = reply.context;
        show('已找到对应课程', reply.title);
      } else if (reply.state === 'outside') {
        show('请先打开课程视频', '从课程主页选择课程，打开对应的 B站视频后，再点击插件。');
      } else if (reply.state === 'unmatched') {
        show('这个视频暂未收录学习笔记', '可以从课程主页选择其他课程；如果这门课刚更新，请重新检查。');
      } else throw new Error('Invalid response');
    } catch {
      if (disposed || ticket !== epoch) return;
      show('课程信息暂时无法加载', '请检查网络后重试，也可以先访问课程主页。');
    } finally { clearTimeout(timer); }
  }
  function invalidate() {
    ++epoch; context = null;
    show('当前页面已变化', '请重新检查当前视频，或从课程主页选择课程。');
  }
  const updated = (id, change) => { if (id === tabId && (change.url || change.status === 'loading')) invalidate(); };
  const activated = info => { if (info.windowId === windowId && info.tabId !== tabId) invalidate(); };
  const removed = id => { if (id === tabId) invalidate(); };
  api.tabs.onUpdated.addListener(updated); api.tabs.onActivated.addListener(activated); api.tabs.onRemoved.addListener(removed);
  $('retry').addEventListener('click', () => { void check(true); });
  $('open-panel').addEventListener('click', () => {
    if (!context || disposed) return;
    const owner = context, ticket = epoch;
    // The tab-specific path was prepared by the worker. Keep open() in this
    // explicit user gesture; never auto-open when the network request completes.
    $('open-panel').disabled = true;
    const notice = (state, stage, detail) => {
      if (api.tabs.sendMessage) void api.tabs.sendMessage(owner.tabId, {
        type: 'fabricademy-panel-loading', state, stage, detail, expected: owner.video
      }).catch(() => {});
    };
    notice('loading');
    api.sidePanel.open({ tabId: owner.tabId }).then(() => {
      notice('phase', 'opened');
      void api.runtime.sendMessage({ type: 'panel:ping', tabId: owner.tabId, courseId: owner.courseId })
        .then(reply => { if (reply?.ready) notice('ready'); }).catch(() => {});
      close();
    }).catch(error => {
      notice('error', 'error', String(error.message || error).slice(0, 200));
      if (disposed || ticket !== epoch) return;
      context = null; show('学习面板暂时无法打开', '请重新检查后再试；必要时刷新视频页面。');
    });
  });
  const ready = (async () => {
    try {
      const [tab] = await api.tabs.query({ active: true, currentWindow: true });
      if (disposed) return;
      tabId = tab?.id; windowId = tab?.windowId;
      await check();
    } catch { if (!disposed) show('无法读取当前页面', '请重新打开插件，也可以先访问课程主页。'); }
  })();
  void api.storage.local.get('fabricademy-panel-theme').then(value => {
    const theme = value['fabricademy-panel-theme'];
    if (['light', 'mid', 'dark'].includes(theme)) doc.documentElement.dataset.theme = theme;
  }).catch(() => {});
  function dispose() {
    disposed = true; ++epoch; context = null;
    api.tabs.onUpdated.removeListener(updated); api.tabs.onActivated.removeListener(activated); api.tabs.onRemoved.removeListener(removed);
  }
  return { ready, dispose };
}
if (typeof chrome !== 'undefined' && chrome.runtime?.id) {
  const popup = createPopup(chrome, document);
  window.addEventListener('pagehide', popup.dispose, { once: true });
}
