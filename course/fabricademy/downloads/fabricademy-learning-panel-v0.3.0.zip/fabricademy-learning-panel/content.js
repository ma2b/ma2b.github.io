(() => {
  'use strict';
  const CHANNEL = 'fabricademy-study-media-v1';
  const pending = new Map();
  window.addEventListener('message', event => {
    const m = event.data;
    if (event.source !== window || event.origin !== location.origin || m?.channel !== CHANNEL || m.kind !== 'response') return;
    const entry = pending.get(m.requestId);
    if (!entry) return;
    clearTimeout(entry.timer); pending.delete(m.requestId); entry.reply(m.result);
  });
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id || message?.type !== 'fabricademy-media' || !['state', 'seek', 'pause', 'play'].includes(message.command)) return;
    const requestId = crypto.randomUUID();
    const timer = setTimeout(() => {
      pending.delete(requestId); reply({ ok: false, error: '无法连接 B站播放器，请刷新视频页面后重试' });
    }, 4000);
    pending.set(requestId, { reply, timer });
    window.postMessage({ channel: CHANNEL, kind: 'request', requestId,
      command: message.command, expected: message.expected, time: message.time }, location.origin);
    return true;
  });
})();
