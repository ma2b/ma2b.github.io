import { BUNDLE_BINDINGS, BUNDLE_REVISION } from './data/bindings.js';
import { CACHE_KEY, validateCatalog } from './model.js';
import { createTabPanelController } from './panel-scope.js';

const controller = createTabPanelController(chrome, BUNDLE_BINDINGS);
const initialized = controller.initialize();
let cacheEpoch = 0;
async function updateBindings() {
  const epoch = ++cacheEpoch;
  let bindings = BUNDLE_BINDINGS;
  try {
    const stored = await chrome.storage.local.get(CACHE_KEY);
    const cache = stored[CACHE_KEY];
    if (cache?.base_revision === BUNDLE_REVISION) {
      bindings = validateCatalog(cache.catalog).courses.filter(c => c.bilibili)
        .map(c => ({ course_id: c.id, ...c.bilibili }));
    }
  } catch { /* The verified bundle remains usable if the cache is unavailable. */ }
  await initialized;
  if (epoch === cacheEpoch) await controller.setBindings(bindings);
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes[CACHE_KEY]) void updateBindings();
});
void updateBindings();
