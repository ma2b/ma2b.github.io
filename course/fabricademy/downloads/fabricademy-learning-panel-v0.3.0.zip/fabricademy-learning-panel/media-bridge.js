(() => {
  'use strict';
  // MAIN world is used only for the public media properties of B站's custom
  // bwp-video element. No cookies, player internals or stream addresses are read.
  const CHANNEL = 'fabricademy-study-media-v1';
  function identity() {
    const match = location.pathname.match(/^\/video\/(BV[0-9A-Za-z]{10})\/?$/);
    const p = Number(new URL(location.href).searchParams.get('p') || 1);
    return match && Number.isInteger(p) && p > 0 ? { bvid: match[1], p } : null;
  }
  function mediaElements(root) {
    const found = [...root.querySelectorAll('video, bwp-video')];
    for (const node of root.querySelectorAll('*')) if (node.shadowRoot) found.push(...mediaElements(node.shadowRoot));
    return found;
  }
  function player() {
    const roots = [...document.querySelectorAll('#bilibili-player, #bilibiliPlayer, .bpx-player-container, .bilibili-player')];
    const candidates = [...new Set(roots.flatMap(mediaElements))].filter(el =>
      typeof el.play === 'function' && typeof el.pause === 'function' && Number.isFinite(el.currentTime));
    return candidates.sort((a, b) => {
      const area = el => { const r = el.getBoundingClientRect(); return r.width * r.height; };
      return area(b) - area(a);
    })[0];
  }
  function state() {
    const id = identity(), video = player();
    return { ...id, ready: !!video && Number.isFinite(video.duration) && video.duration > 0,
      currentTime: video?.currentTime || 0, duration: Number.isFinite(video?.duration) ? video.duration : 0,
      paused: video ? !!video.paused : true, seeking: !!video?.seeking };
  }
  let controlBusy = false;
  async function handle(message) {
    if (message.command === 'state') return { ok: true, state: state() };
    if (!['seek', 'pause', 'play'].includes(message.command)) throw new Error('不支持的播放操作');
    const id = identity(), expected = message.expected;
    if (!id || !expected || id.bvid !== expected.bvid || id.p !== expected.p) throw new Error('当前视频或分 P 已改变，请重新选择课程');
    const video = player();
    if (!video || !Number.isFinite(video.duration) || video.duration <= 0) throw new Error('播放器尚未就绪，请先在 B站点击播放');
    if (!Number.isFinite(expected.duration) || Math.abs(video.duration - expected.duration) > Math.max(8, expected.duration * .005)) {
      throw new Error('视频时长与课程时间轴不一致，已停止定位');
    }
    if (message.command === 'pause') video.pause();
    else {
      if (message.command === 'seek') {
        if (!Number.isFinite(message.time) || message.time < 0 || message.time >= video.duration) throw new Error('时间点超出视频范围');
        video.currentTime = message.time;
        if (Math.abs(video.currentTime - message.time) > 2) throw new Error('播放器未接受时间定位，请在 B站确认播放器状态');
      }
      // Do not hang on an unresolved media play() promise when the network stalls.
      const result = video.play();
      if (result?.then) {
        let timer;
        try {
          await Promise.race([result, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('播放仍在加载，请在 B站确认')), 2500); })]);
        } catch { return { ok: true, state: state(), warning: '已请求定位，播放需在 B站页面确认。' }; }
        finally { clearTimeout(timer); }
      }
    }
    return { ok: true, state: state() };
  }
  window.addEventListener('message', async event => {
    const m = event.data;
    if (event.source !== window || event.origin !== location.origin || m?.channel !== CHANNEL || m.kind !== 'request' || typeof m.requestId !== 'string') return;
    if (!['state', 'seek', 'pause', 'play'].includes(m.command)) return;
    const controlling = m.command !== 'state';
    let result;
    if (controlling && controlBusy) result = { ok: false, error: '上一项播放操作尚未完成，请稍后重试' };
    else {
      if (controlling) controlBusy = true;
      try { result = await handle(m); }
      catch (error) { result = { ok: false, error: error.message }; }
      finally { if (controlling) controlBusy = false; }
    }
    window.postMessage({ channel: CHANNEL, kind: 'response', requestId: m.requestId, result }, location.origin);
  });
})();
