export const SITE_ROOT = 'https://ma2b.github.io/course/fabricademy/';
export const CACHE_KEY = 'fabricademy-fixed-ai-courses-v1';

export function bilibiliIdentity(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== 'https:' || url.hostname !== 'www.bilibili.com') return null;
    const match = url.pathname.match(/^\/video\/(BV[0-9A-Za-z]{10})\/?$/);
    const p = Number(url.searchParams.get('p') || 1);
    return match && Number.isInteger(p) && p > 0 ? { bvid: match[1], p } : null;
  } catch { return null; }
}

export function seconds(value) {
  if (typeof value === 'number') return value;
  if (!/^\d{2,}:\d{2}(?::\d{2})?(?:\.\d+)?$/.test(value || '')) return NaN;
  return value.split(':').reduce((n, part) => n * 60 + Number(part), 0);
}

export function clock(value) {
  const n = Math.max(0, Math.floor(value || 0));
  const parts = [Math.floor(n / 60) % 60, n % 60].map(x => String(x).padStart(2, '0'));
  if (n >= 3600) parts.unshift(String(Math.floor(n / 3600)).padStart(2, '0'));
  return parts.join(':');
}

export function sameVideo(a, b) { return !!a && !!b && a.bvid === b.bvid && a.p === b.p; }
export function chapterAt(course, time) {
  return course.chapters.find(c => time >= c.start && time < c.end)
    || (time === course.duration ? course.chapters.at(-1) : null);
}

function assert(ok, message) { if (!ok) throw new Error(message); }
function text(value) { return typeof value === 'string' && value.length > 0 && value.length < 30000; }
export function safeLink(value) {
  try { const u = new URL(value); return ['https:', 'http:'].includes(u.protocol) && !u.username && !u.password ? u.href : null; }
  catch { return null; }
}
export function courseURL(value) {
  const url = safeLink(value);
  return url && url.startsWith(SITE_ROOT) && !new URL(url).search && !new URL(url).hash ? url : null;
}
export function imageURL(value) {
  return typeof value === 'string' && (/^assets\/[\w./-]+\.(?:jpg|png|webp)$/.test(value) && !value.includes('..')
    || !!courseURL(value) && /\.(?:jpg|png|webp)$/.test(value)) ? value : null;
}

export function validateCourse(course) {
  assert(course && /^\d+$/.test(course.id) && text(course.title), '课程标识或标题无效');
  assert(courseURL(course.page_url), '课程网页不在已授权的网站目录');
  assert(Number.isFinite(course.duration) && course.duration > 0 && course.duration < 86400, '课程时长无效');
  assert(Array.isArray(course.chapters) && course.chapters.length > 0 && course.chapters.length <= 300, '章节数量无效');
  if (course.bilibili) {
    const b = course.bilibili;
    assert(/^BV[0-9A-Za-z]{10}$/.test(b.bvid) && Number.isInteger(b.p) && b.p > 0, 'B站标识无效');
    assert(Number.isFinite(b.offset_seconds) && b.offset_seconds >= 0, '时间偏移无效');
  }
  const ids = new Set();
  let last = 0;
  for (const c of course.chapters) {
    assert(text(c.id) && /^[\w-]+$/.test(c.id) && !ids.has(c.id), '章节 ID 缺失或重复'); ids.add(c.id);
    assert(text(c.title) && text(c.summary), '章节标题或摘要缺失');
    assert(Number.isFinite(c.start) && Number.isFinite(c.end) && Math.abs(c.start - last) < .01 && c.end > c.start, '章节时间不连续');
    last = c.end;
    for (const key of ['key_points', 'actions']) assert(Array.isArray(c[key]) && c[key].every(text), `${key} 内容无效`);
    assert(Array.isArray(c.terms) && c.terms.every(t => text(t.term) && text(t.definition)), '术语无效');
    for (const key of ['moments', 'frames']) {
      assert(Array.isArray(c[key]) && c[key].length < 500, `${key} 内容无效`);
      for (const item of c[key]) {
        // Published image captions show whole seconds, allowing < 1 s rounding down.
        assert(Number.isFinite(item.time) && item.time >= c.start - (key === 'frames' ? 1 : .01) && item.time < c.end, '章内时间点越界');
        assert(key === 'frames' ? text(item.caption) && imageURL(item.src) : text(item.title), '章内内容无效');
        if (item.fallback_src) assert(imageURL(item.fallback_src), '备用图片路径无效');
      }
    }
    assert(Array.isArray(c.references) && c.references.every(r => text(r.title) && safeLink(r.url)), '参考资料无效');
  }
  assert(Math.abs(last - course.duration) < .01, '章节未覆盖完整视频');
  return course;
}

export function validateCatalog(data) {
  assert(data?.schema_version === 1 && Array.isArray(data.courses) && data.courses.length > 0 && data.courses.length <= 100, '课程数据格式无效');
  const ids = new Set(), videos = new Set();
  for (const course of data.courses) {
    validateCourse(course);
    assert(!ids.has(course.id), '课程 ID 重复'); ids.add(course.id);
    if (course.bilibili) {
      const key = `${course.bilibili.bvid}:${course.bilibili.p}`;
      assert(!videos.has(key), '同一个 B站视频重复绑定课程'); videos.add(key);
    }
  }
  return data;
}

// Parse only the known generated data assignment. Never evaluate page JavaScript.
export function parsePublishedCourse(html, current, DOMParserClass = DOMParser) {
  assert(typeof html === 'string' && html.length < 8_000_000, '课程网页过大或内容无效');
  const doc = new DOMParserClass().parseFromString(html, 'text/html');
  const config = doc.querySelector('script[data-learning-player-config]')?.textContent.trim();
  const match = config?.match(/^window\.fabricademyPlayback\s*=\s*(\{[\s\S]*\});?$/);
  const sections = [...doc.querySelectorAll('section.chapter')];
  // The currently published 2026-09-21 pages predate playback JSON. For this
  // format, preserve the verified precise timeline/BV and verify all boundaries.
  let legacy = !config;
  let playback;
  if (legacy) {
    assert(sections.length === current.chapters.length, '旧版网页章节结构已变化，需要重新生成扩展课程包');
    for (let i = 0; i < sections.length; i++) {
      const node = sections[i], c = current.chapters[i], link = node.querySelector('.chapter-time');
      const source = safeLink(link?.getAttribute('href'));
      assert(source && new URL(source).hostname === 'vimeo.com' && new URL(source).pathname.split('/')[1] === current.id, '网页与课程 ID 不匹配');
      const times = link.textContent.match(/(\d{2,}:\d{2}(?::\d{2})?)\s*→\s*(\d{2,}:\d{2}(?::\d{2})?)/);
      assert(node.id === c.id && times && Math.abs(seconds(times[1]) - c.start) <= 1.001 && Math.abs(seconds(times[2]) - c.end) <= 1.001,
        '旧版网页章节边界已变化，保留现有精确时间轴；请重新生成扩展课程包');
    }
    playback = { course_id: current.id, duration: current.duration,
      chapters: current.chapters.map((c, i) => ({ ...c, title: sections[i].querySelector('.chapter-title')?.textContent.trim() })) };
  } else {
    assert(match, '课程网页格式已变化，保留现有版本');
    playback = JSON.parse(match[1]);
  }
  assert(String(playback.course_id) === current.id, '网页与课程 ID 不匹配');
  const title = doc.querySelector('.hero h1')?.textContent.trim();
  assert(sections.length === playback.chapters.length, '网页章节与时间轴不一致');
  const chapters = playback.chapters.map(meta => {
    const node = sections.find(el => el.id === meta.id);
    assert(node, '课程缺少章节');
    const body = legacy ? node : node.querySelector('[data-chapter-panel="details"]');
    assert(body, '课程缺少 AI 详情');
    const txt = selector => body.querySelector(selector)?.textContent.trim() || '';
    const texts = selector => [...body.querySelectorAll(selector)].map(el => el.textContent.trim());
    const old = current.chapters.find(c => c.id === meta.id);
    return {
      id: meta.id, title: meta.title, start: Math.round(meta.start * 1000) / 1000, end: Math.round(meta.end * 1000) / 1000,
      summary: txt('.tldr'), key_points: texts('.key-points > li'), actions: texts('.actions li'),
      terms: [...body.querySelectorAll('.term')].map(el => ({ term: el.querySelector('strong')?.textContent.trim(), definition: el.querySelector('.term-tip')?.textContent.trim() })),
      moments: [...body.querySelectorAll('.chapter-moments li')].map(el => {
        const link = el.querySelector(legacy ? 'a' : '[data-seek]');
        assert(link, '小节缺少时间点');
        const copy = el.cloneNode(true); copy.querySelector('a').remove();
        const title = copy.textContent.trim();
        let time = legacy ? seconds(link.textContent.replace('▶', '').trim()) : Math.round(Number(link.dataset.seek) * 1000) / 1000;
        if (legacy) {
          const oldMoment = old?.moments.find(m => m.title === title && Math.abs(m.time - time) < 1.001);
          if (oldMoment) time = oldMoment.time;
        }
        return { time, title };
      }),
      frames: [...body.querySelectorAll('.carousel-img')].map(el => {
        const caption = el.getAttribute('data-caption') || el.alt;
        const match = caption.match(/^(\d{2,}:\d{2}(?::\d{2})?)\s*·\s*(.+)$/);
        assert(match, '图片时间与图注缺失');
        const src = new URL(el.getAttribute('src'), current.page_url).href;
        const fallback = old?.frames.find(f => f.caption === match[2] && Math.floor(f.time) === seconds(match[1])
          && (f.src === src || src.endsWith('/' + f.src.replace(/^assets\/[\w-]+\//, ''))));
        return { time: seconds(match[1]), caption: match[2], src, ...(fallback ? { fallback_src: fallback.fallback_src || fallback.src } : {}) };
      }),
      references: [...body.querySelectorAll('.chapter-section')]
        .filter(section => section.querySelector('.chapter-section-title')?.textContent.trim() === '核对资料')
        .flatMap(section => [...section.querySelectorAll('a')].map(el => ({ title: el.textContent.trim(), url: el.getAttribute('href') })))
    };
  });
  const sources = (playback.sources || []).filter(s => s.provider === 'bilibili' && s.url);
  const source = sources.find(s => s.id === playback.default_source) || sources[0];
  const identity = source ? bilibiliIdentity(source.url) : null;
  assert(!source || identity, '网页 B站链接无效');
  const next = { ...current, title: title || current.title, duration: playback.duration, chapters,
    bilibili: legacy || current.binding_source === 'extension' ? current.bilibili : identity ? { ...identity, offset_seconds: source.offset_seconds || 0 } : null };
  return validateCourse(next);
}

export async function syncPublishedCatalog(current, fetcher = fetch, DOMParserClass = DOMParser) {
  const results = await Promise.all(current.courses.map(async course => {
    try {
    const response = await fetcher(course.page_url, { credentials: 'omit', cache: 'no-cache', redirect: 'error', signal: AbortSignal.timeout(20000) });
    if (!response.ok) throw new Error(`${course.title}：HTTP ${response.status}`);
    const length = Number(response.headers.get('content-length') || 0);
    if (length > 8_000_000) throw new Error('课程网页过大');
    return { course: parsePublishedCourse(await response.text(), course, DOMParserClass), ok: true };
    } catch (error) { return { course, ok: false, error: error.message }; }
  }));
  // A missing/unpublished course retains its previous content; validated courses
  // can still update. Persist the combined catalog in one atomic storage write.
  const report = { updated: results.filter(r => r.ok).map(r => r.course.id),
    failed: results.filter(r => !r.ok).map(r => ({ id: r.course.id, title: r.course.title, error: r.error })) };
  if (!report.updated.length) throw new Error(`所有课程均未能更新。${report.failed[0].error}`);
  return validateCatalog({ ...current, courses: results.map(r => r.course), synced_at: new Date().toISOString(), sync_report: report });
}

// Outline validation reuses the established timing/text/media checks without
// requiring or manufacturing chapter bodies in the stored/returned data.
const outlineChapter = c => ({ ...c, summary: '章节目录', key_points: [], actions: [], terms: [], frames: [], references: [] });
export function validateOutline(course) {
  validateCourse({ ...course, chapters: course.chapters?.map(outlineChapter) });
  for (const c of course.chapters) {
    assert(c.url === `${SITE_ROOT}data/chapters/${course.id}/${c.id}.json` && /^[a-f0-9]{64}$/.test(c.sha256), '章节地址或哈希无效');
  }
  return course;
}
export function validateSelection(index, course) {
  assert(index?.schema_version === 1 && Array.isArray(index.courses), '课程目录无效');
  const entry = index.courses.find(c => c.id === course?.id);
  assert(entry, '课程未收录');
  for (const key of ['id', 'title', 'duration', 'page_url', 'bilibili'])
    assert(JSON.stringify(course[key]) === JSON.stringify(entry[key]), '课程与目录不匹配');
  validateOutline(course);
  validateCourse({ ...course, chapters: course.chapters.map(c => c.summary === undefined ? outlineChapter(c) : c) });
  for (const c of course.chapters) for (const frame of c.frames || [])
    assert(courseURL(frame.src) && !frame.fallback_src, '图片必须来自课程网站');
  return course;
}
