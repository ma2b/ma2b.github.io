import { clock, bilibiliIdentity, sameVideo, chapterAt, validateCatalog, validateSelection } from './model.js';

const api = globalThis.chrome?.runtime?.id ? chrome : null;
const $ = id => document.getElementById(id);
const state = { catalog: null, course: null, chapter: null, tab: null,
  owner: null, video: null, media: null, windowId: null, timer: null, polling: false, controlling: false, syncing: false,
  connectionError: null, controlError: null, presented: false, paint: null, lazy: false, selecting: false, selectionRequest: 0 };
const diagnosticStarted = performance.now(), diagnosticLines = [];
function diagnose(stage, detail = '') {
  const clean = String(detail).replace(/[\r\n]/g, ' ').slice(0, 240);
  const line = `${((performance.now() - diagnosticStarted) / 1000).toFixed(1)}s ${stage}${clean ? ' · ' + clean : ''}`;
  diagnosticLines.push(line); if (diagnosticLines.length > 30) diagnosticLines.shift();
  if ($('diagnostic-log')) $('diagnostic-log').textContent = diagnosticLines.join('\n');
  notifyLoading('phase', stage, clean);
}

function readOwner() {
  const query = new URLSearchParams(location.search), id = query.get('tabId');
  if (!id || !/^\d+$/.test(id) || !Number.isSafeInteger(Number(id))) return null;
  const course = state.catalog.courses.find(c => c.id === query.get('courseId'));
  const video = { bvid: query.get('bvid'), p: Number(query.get('p')) };
  return sameVideo(course?.bilibili, video) ? { tabId: Number(id), courseId: course.id, video } : null;
}
function ownsTab(tab) {
  return state.owner && tab?.id === state.owner.tabId && tab.active
    && sameVideo(bilibiliIdentity(tab.pendingUrl || tab.url), state.owner.video)
    && sameVideo(state.catalog.courses.find(c => c.id === state.owner.courseId)?.bilibili, state.owner.video);
}

function element(tag, text, className) {
  const el = document.createElement(tag);
  if (text !== undefined) el.textContent = text;
  if (className) el.className = className;
  return el;
}
function button(text, action, className) {
  const el = element('button', text, className); el.type = 'button'; el.addEventListener('click', action); return el;
}
function message(text) { $('status').textContent = text; }
function notifyLoading(status, stage, detail) {
  if (!api) return;
  const query = new URLSearchParams(location.search), tabId = Number(query.get('tabId'));
  if (!query.has('tabId') || !Number.isSafeInteger(tabId) || tabId < 0) return;
  void api.tabs.sendMessage(tabId, { type: 'fabricademy-panel-loading', state: status, stage, detail,
    expected: { bvid: query.get('bvid'), p: Number(query.get('p')) } }).catch(() => {});
}
function presentNotes() {
  if (!state.course || document.hidden || state.paint !== null) return;
  state.paint = requestAnimationFrame(() => {
    state.paint = null;
    if (document.hidden || !state.course) return;
    state.presented = true;
    diagnose('panel-visible', '侧栏可见，绘制回调已执行');
    notifyLoading('ready');
  });
}
function loadUpdateWidget() {
  const root = $('program-update');
  if (!api || !root || $('program-update-loader')) return;
  const version = api.runtime.getManifest?.().version || '未知';
  root.textContent = `插件 v${version} · 正在准备版本检查…`;
  const style = document.createElement('link'); style.rel = 'stylesheet'; style.href = 'update-ui.css';
  const script = document.createElement('script'); script.type = 'module';
  script.id = 'program-update-loader'; script.src = 'update-ui.js';
  script.addEventListener('error', () => { root.textContent = `插件 v${version} · 版本检查暂时无法启动`; });
  // Optional UI and its imports must not hold the initial document load open.
  // Do not await it: notes, startup errors and media work independently.
  document.head.append(style); document.body.append(script);
}
function asset(src) { return globalThis.__STUDY_PREVIEW__ && src.startsWith('assets/') ? 'extension/' + src : src; }
function setImage(img, frame) {
  img.src = asset(frame.src); img.alt = frame.caption;
  img.addEventListener('error', () => {
    if (frame.fallback_src && img.dataset.fallback !== 'true') { img.dataset.fallback = 'true'; img.src = asset(frame.fallback_src); }
    else img.alt = `图片暂时不可用：${frame.caption}`;
  });
}
function canControl() {
  const mapping = state.course?.bilibili;
  return api && !state.selecting && !document.hidden && ownsTab(state.tab) && state.course.id === state.owner.courseId
    && sameVideo(mapping, state.video) && state.media?.ready
    && Math.abs(state.media.duration - state.course.duration - mapping.offset_seconds) <= Math.max(8, state.course.duration * .005);
}
function playingChapter() {
  return canControl()
    ? chapterAt(state.course, state.media.currentTime - state.course.bilibili.offset_seconds) : null;
}
function timeButton(time, label = `▶ ${clock(time)}`) {
  const el = button(label, () => control('seek', time), 'time-button');
  el.dataset.seek = String(time); el.title = `从 ${clock(time)} 播放视频`;
  el.disabled = !canControl() || state.controlling;
  return el;
}
function renderCourseOptions() {
  $('course').replaceChildren(...state.catalog.courses.map(c => {
    const option = element('option', c.title); option.value = c.id; return option;
  }));
}
function acceptSelection(reply) {
  if (!reply?.ok) throw new Error(reply?.error || '课程后台没有回应');
  const course = validateSelection(reply.catalog, reply.course);
  const previous = state.catalog?.courses.find(c => c.id === course.id);
  // Reuse only chapter bodies verified against the same per-chapter hash.
  course.chapters = course.chapters.map(c => {
    const old = previous?.chapters?.find(p => p.id === c.id && p.sha256 === c.sha256 && p.summary !== undefined);
    return c.summary === undefined && old ? old : c;
  });
  state.lazy = true;
  state.catalog = { ...reply.catalog, courses: reply.catalog.courses.map(c => c.id === course.id ? course : c) };
  return course;
}
async function loadSelection(id, chapterId, force = false) {
  const request = ++state.selectionRequest;
  state.selecting = true;
  $('loading').hidden = false; $('loading').classList.remove('failed');
  $('loading-label').textContent = '正在读取所选章节…';
  $('reading-pane').setAttribute('aria-busy', 'true'); renderConnection();
  diagnose('chapter-request', '按需读取所选课程目录与一个章节');
  let deadline;
  try {
    const reply = await Promise.race([
      api.runtime.sendMessage({ type: force ? 'courses:refresh' : 'course:get', courseId: id, chapterId }),
      new Promise((_, reject) => { deadline = setTimeout(() => reject(new Error('章节读取超时，请重试')), 25000); })
    ]);
    if (request !== state.selectionRequest) return;
    acceptSelection(reply); state.selecting = false;
    renderCourseOptions(); selectCourse(id, reply.chapterId); renderVersion();
    message(force ? '已更新课程目录与当前章节，其他内容打开时读取。' : '');
    diagnose('chapter-ready', `1 门课程目录 · 1 章正文；${reply.diagnostics?.source === 'cache' ? '缓存' : '按需读取'}`);
    presentNotes();
  } catch (error) {
    if (request !== state.selectionRequest) return;
    $('course').value = state.course.id;
    message(`章节读取未完成，保留现有内容。${error.message}`);
    diagnose('chapter-error', error.message);
  } finally {
    clearTimeout(deadline);
    if (request === state.selectionRequest) {
      state.selecting = false; $('loading').hidden = true;
      $('reading-pane').removeAttribute('aria-busy'); renderConnection();
    }
  }
}
function selectCourse(id, chapterId) {
  const course = state.catalog.courses.find(c => c.id === id) || state.catalog.courses[0];
  const chapter = course.chapters?.find(c => c.id === chapterId) || course.chapters?.[0];
  if (state.lazy && chapter?.summary === undefined) { void loadSelection(course.id, chapterId); return; }
  ++state.selectionRequest; state.selecting = false;
  $('loading').hidden = true; $('reading-pane').removeAttribute('aria-busy');
  state.controlError = null;
  state.course = state.catalog.courses.find(c => c.id === id) || state.catalog.courses[0];
  state.chapter = state.course.chapters.find(c => c.id === chapterId) || state.course.chapters[0];
  $('course').value = state.course.id;
  $('course-meta').textContent = `${state.course.chapters.length} 章 · ${clock(state.course.duration)}`;
  $('course-page').href = state.course.page_url;
  $('search').value = '';
  renderDirectory(); renderChapter(); renderConnection();
  $('reading-pane').scrollTop = 0; $('chapter-list').scrollTop = 0;
}
function selectChapter(id, scroll = true) {
  const target = state.course.chapters.find(c => c.id === id) || state.course.chapters[0];
  if (state.lazy && target.summary === undefined) { void loadSelection(state.course.id, id); return; }
  ++state.selectionRequest; state.selecting = false;
  $('loading').hidden = true; $('reading-pane').removeAttribute('aria-busy');
  state.chapter = state.course.chapters.find(c => c.id === id) || state.course.chapters[0];
  renderChapter(); markDirectory(); renderConnection();
  if (scroll) $('reading-pane').scrollTop = 0;
}
function renderDirectory() {
  const query = $('search').value.trim().toLocaleLowerCase();
  $('chapter-count').textContent = `${state.course.chapters.length} 章`;
  const rows = state.course.chapters.flatMap((c, i) => {
    const haystack = [c.title, ...c.moments.map(m => m.title)].join(' ').toLocaleLowerCase();
    if (query && !haystack.includes(query)) return [];
    const row = element('div', undefined, 'chapter-row'); row.dataset.chapterId = c.id;
    const title = button(`${String(i + 1).padStart(2, '0')}. ${c.title}`, () => selectChapter(c.id), 'chapter-link');
    title.setAttribute('aria-controls', `moments-${c.id}`);
    const list = element('ol', undefined, 'chapter-subsections'); list.id = `moments-${c.id}`;
    list.setAttribute('aria-label', `${c.title}的时间点`);
    const start = element('li'); start.append(timeButton(c.start, `▶ ${clock(c.start)} · 本章开始`)); list.append(start);
    for (const m of c.moments) {
      const li = element('li'), heading = element('h3', undefined, 'moment-heading');
      const seek = timeButton(m.time); seek.replaceChildren(element('span', `▶ ${clock(m.time)}`, 'moment-time'), element('span', m.title, 'moment-title'));
      seek.setAttribute('aria-label', `从 ${clock(m.time)} 播放：${m.title}`);
      heading.append(seek); li.append(heading); list.append(li);
    }
    row.append(title, list); return [row];
  });
  $('chapter-list').replaceChildren(...(rows.length ? rows : [element('p', '没有匹配章节，换一个关键词试试。', 'hint')]));
  markDirectory();
}
function markDirectory() {
  const playing = playingChapter()?.id;
  for (const row of document.querySelectorAll('.chapter-row')) {
    const reading = row.dataset.chapterId === state.chapter.id;
    row.classList.toggle('reading', reading); row.classList.toggle('playing', row.dataset.chapterId === playing);
    const showTimes = reading || !!$('search').value.trim();
    row.querySelector('.chapter-subsections').hidden = !showTimes;
    row.firstChild.setAttribute('aria-expanded', String(showTimes));
    if (reading) row.firstChild.setAttribute('aria-current', 'true'); else row.firstChild.removeAttribute('aria-current');
  }
}
function renderChapter() {
  const c = state.chapter, index = state.course.chapters.indexOf(c), article = $('chapter');
  const kicker = element('div', undefined, 'chapter-kicker');
  kicker.append(element('span', '课程详情'), element('span', `CHAPTER ${String(index + 1).padStart(2, '0')}`));
  const range = element('p', undefined, 'chapter-range');
  range.append(timeButton(c.start, `▶ ${clock(c.start)}`), document.createTextNode(` — ${clock(c.end)} · 本章开始`));
  article.replaceChildren(kicker, element('h1', c.title), range, element('h2', '本章摘要'), element('p', c.summary, 'summary'));
  for (const f of c.frames) {
    const figure = element('figure', undefined, 'frame'), img = element('img');
    img.loading = 'lazy'; setImage(img, f);
    const enlarge = button('', () => {
      $('large-image').removeAttribute('data-fallback');
      $('large-image').src = img.src; $('large-image').alt = f.caption;
      $('large-caption').textContent = `${clock(f.time)} · ${f.caption}`;
      $('image-dialog').showModal();
    }, 'image-button');
    enlarge.setAttribute('aria-label', `放大图片：${f.caption}`); enlarge.title = '点击查看大图'; enlarge.append(img);
    const caption = element('figcaption'); caption.append(timeButton(f.time, clock(f.time)), document.createTextNode(` · ${f.caption}`));
    figure.append(enlarge, caption); article.append(figure);
  }
  if (c.key_points.length) {
    const list = element('ul', undefined, 'points'); list.append(...c.key_points.map(p => element('li', p)));
    article.append(element('h2', '关键观点'), list);
  }
  if (c.terms.length) {
    const list = element('dl', undefined, 'terms');
    for (const t of c.terms) { const item = element('div'); item.append(element('dt', t.term), element('dd', t.definition)); list.append(item); }
    article.append(element('h2', '术语速查'), list);
  }
  if (c.actions.length) {
    const list = element('ol', undefined, 'actions'); list.append(...c.actions.map(a => element('li', a)));
    article.append(element('h2', '行动清单'), list);
  }
  if (c.references.length) {
    const list = element('ul', undefined, 'points');
    for (const r of c.references) {
      const li = element('li'), a = element('a', r.title); a.href = r.url; a.target = '_blank'; a.rel = 'noopener noreferrer'; li.append(a); list.append(li);
    }
    article.append(element('h2', '核对资料'), list);
  }
  $('previous').disabled = index === 0; $('next').disabled = index === state.course.chapters.length - 1;
  $('reading-position').textContent = `${index + 1} / ${state.course.chapters.length}`;
}
function renderConnection() {
  const mapping = state.course?.bilibili, connected = canControl();
  $('open-video').hidden = !mapping || sameVideo(mapping, state.video);
  $('toggle-play').disabled = !connected || state.controlling;
  $('toggle-play').textContent = state.media?.paused ? '继续播放' : '暂停精读';
  $('follow-video').disabled = !playingChapter();
  $('connection-dot').classList.toggle('connected', !!connected);
  $('playback-time').textContent = connected ? clock(state.media.currentTime - mapping.offset_seconds) : '--:--';
  let title, detail;
  if (!api) { title = '界面预览'; detail = '这是四门课程的真实 AI 笔记。请加载扩展后连接 B站播放器。'; }
  else if (!state.owner) { title = '请重新打开学习面板'; detail = '请关闭此面板，在已绑定的 B站视频标签页中点击插件图标。'; }
  else if (!mapping) { title = '课程笔记已就绪'; detail = '这门课尚未绑定 B站视频，当前可以阅读全部 AI 内容。'; }
  else if (!ownsTab(state.tab) || state.course.id !== state.owner.courseId || !sameVideo(mapping, state.video)) { title = '等待对应视频'; detail = `请在 ${mapping.bvid} · P${mapping.p} 的标签页手动打开插件。每个面板只连接打开它的视频标签页。`; }
  else if (!state.media?.ready && state.connectionError) { title = '播放器连接中断'; detail = state.connectionError; }
  else if (!state.media?.ready) { title = '等待播放器就绪'; detail = '请先在 B站点击播放。首次安装或重新加载扩展后，请刷新视频页面。'; }
  else if (!connected) { title = '视频时间轴不匹配'; detail = `课程 ${clock(state.course.duration)}，视频 ${clock(state.media.duration)}。暂不启用定位，请确认上传版本。`; }
  else { title = state.media.paused ? '已连接 · 已暂停' : '已连接 · 正在播放'; detail = playingChapter() ? `视频所在：${playingChapter().title}` : '播放器已连接，可按时间点学习。'; }
  if (state.controlError && connected) detail = state.controlError;
  $('connection-title').textContent = title; $('connection-detail').textContent = detail;
  $('connection-detail').hidden = !!connected && !state.controlError;
  $('connection-title').title = detail; $('follow-video').title = detail;
  for (const el of document.querySelectorAll('button[data-seek]')) el.disabled = !connected || state.controlling;
  markDirectory();
}

async function ownerTab() {
  if (!state.owner) return null;
  try { return await api.tabs.get(state.owner.tabId); } catch { return null; }
}
async function mediaRequest(tabId, message) {
  let timeout;
  try {
    return await Promise.race([api.tabs.sendMessage(tabId, message), new Promise((_, reject) => {
      timeout = setTimeout(() => reject(new Error('未收到播放器回复，暂未确认操作结果。请刷新视频页后重新打开插件。')), 5500);
    })]);
  } finally { clearTimeout(timeout); }
}
function updateTimer() {
  const run = api && !document.hidden && ownsTab(state.tab);
  if (!run && state.timer !== null) { clearInterval(state.timer); state.timer = null; }
  if (run && state.timer === null) state.timer = setInterval(poll, 1200);
}
async function poll() {
  if (!api || !state.owner || state.polling || document.hidden) return;
  state.polling = true;
  try {
    const tab = await ownerTab(), video = bilibiliIdentity(tab?.pendingUrl || tab?.url);
    state.tab = tab; state.video = video; state.windowId = tab?.windowId ?? state.windowId;
    if (!ownsTab(tab) || document.hidden) state.media = null;
    else {
      let response;
      try {
        response = await mediaRequest(tab.id, { type: 'fabricademy-media', command: 'state' });
        state.connectionError = response?.ok ? null : response?.error || '播放器连接没有返回有效结果，请刷新视频页后重试。';
      } catch (error) {
        response = null;
        state.connectionError = /Receiving end does not exist|Could not establish connection|message port closed|channel closed|context invalidated/i.test(error.message)
          ? '视频页与插件的连接已失效，常见于插件重新加载后。请刷新这一个视频页，再打开插件。'
          : error.message;
      }
      const current = await ownerTab(); state.tab = current;
      if (!ownsTab(current) || document.hidden) { state.media = null; return; }
      state.media = response?.ok && sameVideo(response.state, video) ? response.state : null;
    }
  } catch { state.tab = null; state.media = null; }
  finally { state.polling = false; updateTimer(); renderConnection(); }
}
async function control(command, time) {
  if (!canControl() || state.controlling) return;
  const course = state.course, tabId = state.tab.id;
  state.controlling = true; state.controlError = null; renderConnection(); message('');
  try {
    const current = await ownerTab(); state.tab = current;
    if (!ownsTab(current) || document.hidden || state.course.id !== course.id) throw new Error('面板所属视频已切换或隐藏，请返回对应标签页');
    const result = await mediaRequest(tabId, { type: 'fabricademy-media', command,
      time: time === undefined ? undefined : time + course.bilibili.offset_seconds,
      expected: { ...course.bilibili, duration: course.duration + course.bilibili.offset_seconds } });
    const now = await ownerTab(); state.tab = now;
    if (!ownsTab(now) || document.hidden || state.course.id !== course.id) { state.media = null; return; }
    if (!result?.ok) throw new Error(result?.error || '播放器没有回应，请刷新 B站页面');
    if (!sameVideo(result.state, state.owner.video)) throw new Error('视频已改变，请返回对应视频后重试');
    state.media = result.state;
    message(result.warning || (command === 'seek' ? `已定位至 ${clock(result.state.currentTime - course.bilibili.offset_seconds)}` : command === 'pause' ? '视频已暂停，可以继续阅读。' : '已请求继续播放。'));
  } catch (error) { state.media = null; state.connectionError = error.message; state.controlError = error.message; message(error.message); }
  finally { state.controlling = false; updateTimer(); renderConnection(); }
}
function renderVersion() {
  $('content-version').textContent = `GitHub 课程数据 · ${state.catalog.courses.length} 门 · ${state.catalog.revision.slice(0, 8)}`;
}
async function sync() {
  if (!api || state.syncing) return;
  state.syncing = true; $('sync').disabled = true; $('sync').textContent = '正在检查…'; message('');
  try {
    if (state.lazy) { await loadSelection(state.course.id, state.chapter.id, true); return; }
    const reply = await api.runtime.sendMessage({ type: 'courses:refresh' });
    if (!reply?.ok) throw new Error(reply?.error || '课程后台没有回应');
    const next = validateCatalog(reply.catalog);
    const id = state.course.id, chapterId = state.chapter.id;
    state.catalog = next; renderCourseOptions(); selectCourse(id, chapterId); renderVersion();
    message('已从 GitHub 更新课程目录与 AI 笔记。新增课程无需重新安装插件。');
    await poll();
  } catch (error) { message(`更新未完成，保留现有内容。${error.message}`); }
  finally { state.syncing = false; $('sync').disabled = false; $('sync').textContent = '更新课程内容'; }
}
async function boot() {
  let data = globalThis.__STUDY_PREVIEW__, initialSelection = null;
  if (api) {
    diagnose('courses-request', '请求后台课程数据');
    let deadline, slow;
    slow = setTimeout(() => { $('loading-label').textContent = '读取较慢，正在等待课程数据…'; }, 8000);
    let reply;
    try {
      reply = await Promise.race([api.runtime.sendMessage({ type: 'courses:get', courseId: new URLSearchParams(location.search).get('courseId') }),
        new Promise((_, reject) => { deadline = setTimeout(() => reject(new Error('课程读取超时，请重试')), 25000); })]);
    } finally { clearTimeout(deadline); clearTimeout(slow); }
    if (!reply?.ok) throw new Error(reply?.error || '首次使用需要联网获取课程');
    data = reply.catalog;
    if (reply.course) initialSelection = reply;
    const timing = reply.diagnostics;
    diagnose('courses-received', `${data?.courses?.length || 0} 门轻量目录${reply.course ? '；已读取 1 门课程目录、1 章正文' : ''}${timing ? `；${timing.source === 'cache' ? '缓存' : '网络'}；缓存读取 ${timing.cache_ms}ms；后台总计 ${timing.total_ms}ms` : ''}`);
    $('loading-label').textContent = '正在准备课程笔记…';
    diagnose('preferences', '读取窗口与外观设置');
    state.windowId = (await api.windows.getCurrent()).id;
    try {
      const stored = await api.storage.local.get('fabricademy-panel-theme');
      const theme = stored['fabricademy-panel-theme'];
      if (['light', 'mid', 'dark'].includes(theme)) { document.documentElement.dataset.theme = theme; $('theme').value = theme; }
    } catch { message('外观偏好无法读取。'); }
  } else { $('preview-notice').hidden = false; $('sync').disabled = true; }
  diagnose('render', '校验并显示笔记');
  if (initialSelection) acceptSelection(initialSelection);
  else state.catalog = validateCatalog(data);
  if (api) state.owner = readOwner();
  renderCourseOptions(); selectCourse(state.owner?.courseId || state.catalog.courses.find(c => c.bilibili)?.id, initialSelection?.chapterId); renderVersion();
  $('loading').hidden = true;
  diagnose('notes-ready', document.hidden ? '笔记内容已准备，等待侧栏可见' : '笔记内容已准备，等待绘制回调');
  presentNotes();
  $('course').addEventListener('change', () => { message(''); selectCourse($('course').value); });
  $('search').addEventListener('input', renderDirectory);
  $('directory-toggle').addEventListener('click', () => {
    const open = $('directory').hidden;
    $('directory').hidden = !open;
    $('study-workspace').classList.toggle('directory-open', open);
    $('directory-toggle').setAttribute('aria-expanded', String(open));
    $('directory-toggle').textContent = open ? '收起章节' : '章节';
  });
  $('position-help-toggle').addEventListener('click', () => {
    const open = $('position-help').hidden;
    $('position-help').hidden = !open;
    $('position-help-toggle').setAttribute('aria-expanded', String(open));
  });
  $('previous').addEventListener('click', () => selectChapter(state.course.chapters[state.course.chapters.indexOf(state.chapter) - 1].id));
  $('next').addEventListener('click', () => selectChapter(state.course.chapters[state.course.chapters.indexOf(state.chapter) + 1].id));
  $('follow-video').addEventListener('click', () => { const chapter = playingChapter(); if (chapter) selectChapter(chapter.id); });
  $('toggle-play').addEventListener('click', () => control(state.media?.paused ? 'play' : 'pause'));
  $('open-video').addEventListener('click', () => {
    if (!state.course.bilibili) return;
    const { bvid, p } = state.course.bilibili, url = `https://www.bilibili.com/video/${bvid}/?p=${p}`;
    if (api) api.tabs.create({ url, windowId: state.windowId }).catch(error => message(error.message));
    else window.open(url, '_blank', 'noopener,noreferrer');
  });
  $('theme').addEventListener('change', async () => {
    const value = $('theme').value; document.documentElement.dataset.theme = value;
    if (api) try { await api.storage.local.set({ 'fabricademy-panel-theme': value }); } catch { message('外观已切换，但未能保存偏好。'); }
  });
  $('close-image').addEventListener('click', () => $('image-dialog').close());
  $('sync').addEventListener('click', sync);
  diagnose('player-request', '读取播放器状态');
  await poll();
  diagnose(canControl() ? 'player-ready' : 'player-error', $('connection-title').textContent + '；' + $('connection-detail').textContent);
  if (api && state.owner) {
    api.tabs.onActivated.addListener(({ tabId, windowId }) => {
      if (tabId === state.owner.tabId || windowId === state.windowId) void poll();
    });
    api.tabs.onUpdated.addListener((id, change) => { if (id === state.owner.tabId && (change.url || change.status)) void poll(); });
    api.tabs.onRemoved.addListener(id => {
      if (id === state.owner.tabId) { state.tab = null; state.media = null; updateTimer(); renderConnection(); }
    });
    window.addEventListener('pagehide', () => { if (state.timer !== null) clearInterval(state.timer); state.timer = null; });
  }
}
function start() {
  diagnose('document-loaded', `侧栏文档已加载；距文档计时起点 ${Math.round(performance.now())}ms`);
  requestAnimationFrame(() => setTimeout(loadUpdateWidget, 0));
  void boot().catch(error => {
  $('loading-label').textContent = '课程加载未完成，请检查网络并重新打开面板。';
  $('loading').classList.add('failed');
  diagnose('error', error.message);
  $('diagnostics').open = true;
  notifyLoading('error', 'error', error.message);
  message(`学习面板未能启动：${error.message}`);
}); }
diagnose('panel-script', `主脚本已执行；插件 v${api?.runtime.getManifest?.().version || '预览'}；文档 ${document.readyState}；距文档计时起点 ${Math.round(performance.now())}ms；实例 ${new Date(performance.timeOrigin).toISOString()}`);
// Chrome hides extension views until the first document load finishes. Start
// network requests and dynamic image rendering only after that load completes.
if (document.readyState === 'complete') setTimeout(start, 0);
else window.addEventListener('load', () => setTimeout(start, 0), { once: true });
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    state.presented = false;
    if (state.paint !== null) cancelAnimationFrame(state.paint);
    state.paint = null;
  } else presentNotes();
  if (state.course) { updateTimer(); renderConnection(); void poll(); }
});
api?.runtime.onMessage?.addListener((message, sender, reply) => {
  if (sender.id === api.runtime.id && message?.type === 'panel:ping'
    && message.tabId === state.owner?.tabId && message.courseId === state.owner?.courseId) {
    diagnose('panel-reused', document.hidden ? '现有页面仍隐藏' : '复用现有页面；未重新启动或读取课程');
    presentNotes();
    reply({ ready: state.presented && !document.hidden });
  }
});
