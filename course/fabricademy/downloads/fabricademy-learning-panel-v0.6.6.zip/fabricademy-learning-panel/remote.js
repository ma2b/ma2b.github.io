import { SITE_ROOT, validateCatalog, validateCourse, courseURL, validateOutline, validateSelection } from './model.js';

export const CATALOG_URL = SITE_ROOT + 'data/catalog.json';
export const REMOTE_CACHE_KEY = 'fabricademy-remote-courses-v1';
export const MAX_AGE = 60 * 60 * 1000;

function check(ok, message) { if (!ok) throw new Error(message); }
export function validateIndex(index) {
  check(index?.schema_version === 1 && /^[a-f0-9]{64}$/.test(index.revision), '课程目录版本无效');
  check(Array.isArray(index.courses) && index.courses.length > 0 && index.courses.length <= 100, '课程目录为空或过大');
  const ids = new Set(), videos = new Set();
  for (const c of index.courses) {
    check(/^\d+$/.test(c.id) && !ids.has(c.id), '课程标识重复或无效'); ids.add(c.id);
    check(c.url === `${SITE_ROOT}data/courses/${c.id}.json` && /^[a-f0-9]{64}$/.test(c.sha256), '课程数据地址或哈希无效');
    check(typeof c.title === 'string' && c.title.length > 0 && courseURL(c.page_url), '课程信息无效');
    check(Number.isFinite(c.duration) && c.duration > 0 && c.duration < 86400, '课程时长无效');
    if (c.bilibili) {
      const b = c.bilibili, key = `${b.bvid}:${b.p}`;
      check(/^BV[0-9A-Za-z]{10}$/.test(b.bvid) && Number.isInteger(b.p) && b.p > 0
        && Number.isFinite(b.offset_seconds) && b.offset_seconds >= 0 && !videos.has(key), '视频绑定无效或重复');
      videos.add(key);
    }
  }
  return index;
}

export function validateRemoteCatalog(catalog) {
  validateCatalog(catalog);
  check(/^[a-f0-9]{64}$/.test(catalog.revision), '课程版本无效');
  for (const course of catalog.courses) for (const chapter of course.chapters) for (const frame of chapter.frames) {
    check(courseURL(frame.src) && !frame.fallback_src, '图片必须来自课程网站');
  }
  return catalog;
}

async function read(url, fetcher, limit, signal) {
  const response = await fetcher(url, { credentials: 'omit', cache: 'no-cache', redirect: 'error', signal });
  check(response.ok, `课程网站 HTTP ${response.status}`);
  check(Number(response.headers.get('content-length') || 0) <= limit, '课程数据过大');
  // Bound decompressed bytes as well, even when Content-Length is missing.
  const reader = response.body.getReader();
  const chunks = []; let size = 0;
  try {
    while (true) {
      const { value, done } = await reader.read(); if (done) break;
      size += value.length; check(size <= limit, '课程数据过大'); chunks.push(value);
    }
  } finally { await reader.cancel(); }
  const bytes = new Uint8Array(size); let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  return bytes;
}

export async function fetchCatalog(previous = null, fetcher = fetch) {
  // One deadline for the entire snapshot, rather than 20 seconds per course.
  const signal = AbortSignal.timeout(20000);
  const decode = bytes => JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
  const index = validateIndex(decode(await read(CATALOG_URL, fetcher, 200000, signal)));
  if (previous?.revision === index.revision) {
    validateRemoteCatalog(previous);
    check(previous.courses.length === index.courses.length && index.courses.every((c, i) =>
      c.id === previous.courses[i].id && JSON.stringify(c.bilibili) === JSON.stringify(previous.courses[i].bilibili)), '相同版本目录不一致');
    return previous;
  }
  const courses = new Array(index.courses.length);
  let cursor = 0, failed = false;
  async function load(position) {
    const entry = index.courses[position];
    const bytes = await read(entry.url, fetcher, 2000000, signal);
    const hash = [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(x => x.toString(16).padStart(2, '0')).join('');
    check(hash === entry.sha256, '课程数据版本尚未同步，请稍后重试');
    const course = validateCourse(decode(bytes));
    for (const key of ['id', 'title', 'duration', 'page_url', 'bilibili'])
      check(JSON.stringify(course[key]) === JSON.stringify(entry[key]), '课程正文与目录不匹配');
    courses[position] = course;
  }
  // Bound concurrency to three; preserve directory order and publish only a
  // complete, validated snapshot after all downloads have succeeded.
  await Promise.all(Array.from({ length: Math.min(3, courses.length) }, async () => {
    try { while (!failed && cursor < courses.length) await load(cursor++); }
    catch (error) { failed = true; throw error; }
  }));
  return validateRemoteCatalog({ schema_version: 1, revision: index.revision, courses, synced_at: new Date().toISOString() });
}

export function createRemoteStore(storage, fetcher = fetch) {
  let current = null, checkedAt = 0, flight = null, cacheFlight = null;
  async function cached() {
    if (current) return current;
    if (cacheFlight) return cacheFlight;
    cacheFlight = (async () => {
      try {
        const item = (await storage.get(REMOTE_CACHE_KEY))[REMOTE_CACHE_KEY];
        if (item) { current = validateRemoteCatalog(item.catalog); checkedAt = Number(item.checked_at) || 0; }
      } catch { /* Invalid caches are never used. */ }
      return current;
    })();
    try { return await cacheFlight; } finally { cacheFlight = null; }
  }
  async function refresh(force = false) {
    if (flight) return flight;
    flight = (async () => {
      await cached();
      if (!force && current && Date.now() - checkedAt < MAX_AGE) return current;
      const next = await fetchCatalog(current, fetcher);
      const now = Date.now();
      await storage.set({ [REMOTE_CACHE_KEY]: { catalog: next, checked_at: now } });
      current = next; checkedAt = now; return current;
    })();
    try { return await flight; } finally { flight = null; }
  }
  return { cached, refresh };
}

// Runtime v2: the shared cache is a small directory, never all course bodies.
// The v1 helpers above remain for legacy export/compatibility verification.
export const DIRECTORY_CACHE_KEY = 'fabricademy-directory-v2';
function validateDirectory(index) {
  validateIndex(index);
  for (const c of index.courses)
    check(c.outline_url === `${SITE_ROOT}data/outlines/${c.id}.json` && /^[a-f0-9]{64}$/.test(c.outline_sha256), '课程目录暂未支持按章加载，请稍后重试');
  return index;
}
const decodeJSON = bytes => JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
const digestBytes = async bytes => [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(x => x.toString(16).padStart(2, '0')).join('');
export function createOnDemandStore(storage, fetcher = fetch) {
  let current = null, checkedAt = 0, cacheFlight = null, refreshFlight = null;
  const memory = new Map(), flights = new Map();
  async function cached() {
    if (current) return current;
    if (cacheFlight) return cacheFlight;
    cacheFlight = (async () => {
      try {
        const record = (await storage.get(DIRECTORY_CACHE_KEY))[DIRECTORY_CACHE_KEY];
        if (record) { current = validateDirectory(record.catalog); checkedAt = Number(record.checked_at) || 0; }
      } catch { /* Invalid directory caches are never used. */ }
      return current;
    })();
    try { return await cacheFlight; } finally { cacheFlight = null; }
  }
  async function refresh(force = false) {
    if (refreshFlight) return refreshFlight;
    refreshFlight = (async () => {
      await cached();
      if (!force && current && Date.now() - checkedAt < MAX_AGE) return current;
      const next = validateDirectory(decodeJSON(await read(CATALOG_URL, fetcher, 200000, AbortSignal.timeout(20000))));
      const now = Date.now();
      await storage.set({ [DIRECTORY_CACHE_KEY]: { catalog: next, checked_at: now } });
      current = next; checkedAt = now; return current;
    })();
    try { return await refreshFlight; } finally { refreshFlight = null; }
  }
  async function item(key, url, sha256, validate, signal, trace) {
    const identity = `${key}:${sha256}`;
    if (memory.has(identity)) return validate(memory.get(identity));
    let flight = flights.get(identity);
    if (!flight) {
      flight = (async () => {
        try {
          const record = (await storage.get(key))[key];
          if (record?.sha256 === sha256) return { value: validate(record.value), network: false };
        } catch { /* Retry corrupt/missing per-item cache through the verified URL. */ }
        const bytes = await read(url, fetcher, 2000000, signal);
        check(await digestBytes(bytes) === sha256, '章节数据版本尚未同步，请稍后重试');
        return { value: validate(decodeJSON(bytes)), network: true };
      })();
      flights.set(identity, flight);
    }
    try {
      const result = await flight;
      // Persist an outline and its selected body together only after both
      // validate, retaining the previous usable pair on mixed deployments.
      if (result.network) { trace.network = true; trace.pending[key] = { sha256, value: result.value }; }
      trace.memory.set(identity, result.value);
      return validate(result.value);
    } finally { if (flights.get(identity) === flight) flights.delete(identity); }
  }
  async function selection(index, courseId, chapterId) {
    const entry = index.courses.find(c => c.id === courseId);
    check(entry, '课程未收录');
    const signal = AbortSignal.timeout(20000), trace = { network: false, pending: {}, memory: new Map() };
    const outline = await item(`fabricademy-outline-v2:${courseId}`, entry.outline_url, entry.outline_sha256,
      value => validateSelection(index, validateOutline(value)), signal, trace);
    const meta = outline.chapters.find(c => c.id === chapterId) || outline.chapters[0];
    const body = await item(`fabricademy-chapter-v2:${courseId}:${meta.id}`, meta.url, meta.sha256, value => {
      for (const key of ['id', 'title', 'start', 'end', 'moments'])
        check(JSON.stringify(value[key]) === JSON.stringify(meta[key]), '章节正文与目录不匹配');
      validateSelection(index, { ...outline, chapters: outline.chapters.map(c => c.id === meta.id ? { ...c, ...value } : c) });
      return value;
    }, signal, trace);
    if (Object.keys(trace.pending).length) await storage.set(trace.pending);
    for (const [key, value] of trace.memory) memory.set(key, value);
    return { course: { ...outline, chapters: outline.chapters.map(c => c.id === meta.id ? { ...c, ...body } : c) },
      chapterId: meta.id, source: trace.network ? 'network' : 'cache' };
  }
  return { cached, refresh, selection };
}
