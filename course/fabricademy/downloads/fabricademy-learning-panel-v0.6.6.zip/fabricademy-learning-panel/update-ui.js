import { SITE_ROOT } from './model.js';
import { compareVersions, validateRelease } from './updates.js';

export function mountUpdates(api, doc) {
  const root = doc.getElementById('program-update');
  if (!root || !api) return { ready: Promise.resolve(), dispose() {} };
  const make = (tag, text, className) => {
    const node = doc.createElement(tag); if (text) node.textContent = text;
    if (className) node.className = className; return node;
  };
  const link = (text, href) => {
    const node = make('a', text); node.href = href; node.target = '_blank'; node.rel = 'noopener noreferrer'; return node;
  };
  const current = api.runtime.getManifest().version;
  const line = make('div', null, 'update-line'), label = make('span', `插件 v${current}`, 'update-current');
  const status = make('span', '正在检查版本…', 'update-status'); status.setAttribute('role', 'status');
  const retry = make('button', '检查更新'); retry.type = 'button';
  line.append(label, status, retry);
  const download = link('前往下载新版 ↗', SITE_ROOT + '#extension'); download.className = 'update-download'; download.hidden = true;
  const details = make('details', null, 'update-details');
  const summary = make('summary', '更新记录与升级方法');
  const body = make('div', null, 'update-body');
  const help = make('p', '下载并解压新版 → 覆盖原插件文件夹 → 在 Chrome 扩展管理页点击「重新加载」→ 刷新视频页。此处检查程序版本；「更新课程内容」只更新 AI 笔记。');
  const history = make('div', null, 'update-history');
  const homepage = link('在课程主页查看完整更新记录 ↗', SITE_ROOT + '#extension-changelog');
  body.append(help, history, homepage); details.append(summary, body);
  root.replaceChildren(line, download, details);
  let busy = false, disposed = false, lastRelease = null;
  function render(reply) {
    let release = null;
    try { if (reply?.release) release = validateRelease(reply.release); } catch { reply = null; }
    release ||= lastRelease; lastRelease = release;
    const known = release && compareVersions(release.version, current);
    const failed = !reply?.ok;
    root.dataset.state = failed ? 'error' : known > 0 ? 'available' : 'current';
    status.textContent = failed ? (known > 0 ? `上次发现 v${release.version} · 本次检查失败` : '检查失败，请重试')
      : known > 0 ? `有新版本 v${release.version}` : known < 0 ? `当前版本高于已发布版 v${release.version}` : '已是最新版本';
    if (!release && !failed) status.textContent = '版本信息不可用，请重试';
    status.title = reply?.checked_at ? `上次成功检查：${new Date(reply.checked_at).toLocaleString('zh-CN')}` : '';
    download.hidden = !(known > 0);
    if (known > 0) download.textContent = `下载新版 v${release.version} ↗`;
    history.replaceChildren();
    if (!release) history.append(make('p', '暂时无法读取更新记录，可前往课程主页查看。'));
    else for (const entry of release.releases) {
      const item = make('section'), heading = make('h3', `v${entry.version} · ${entry.date}`), list = make('ul');
      for (const change of entry.changes) list.append(make('li', change));
      item.append(heading, list); history.append(item);
    }
  }
  async function check(force = false) {
    if (disposed || busy) return;
    busy = true; retry.disabled = true; status.textContent = '正在检查版本…';
    let timer;
    try {
      const reply = await Promise.race([api.runtime.sendMessage({ type: 'updates:check', force }),
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('timeout')), 15000); })]);
      if (!disposed) render(reply);
    } catch { if (!disposed) render(null); }
    finally { clearTimeout(timer); busy = false; if (!disposed) retry.disabled = false; }
  }
  const manual = () => { void check(true); };
  const visible = () => { if (!doc.hidden) void check(); };
  retry.addEventListener('click', manual); doc.addEventListener('visibilitychange', visible);
  const ready = check();
  return { ready, dispose() { disposed = true; retry.removeEventListener('click', manual); doc.removeEventListener('visibilitychange', visible); } };
}
if (typeof chrome !== 'undefined' && chrome.runtime?.id) {
  const start = () => {
    const widget = mountUpdates(chrome, document);
    window.addEventListener('pagehide', widget.dispose, { once: true });
  };
  if (document.readyState === 'complete') setTimeout(start, 0);
  else window.addEventListener('load', () => setTimeout(start, 0), { once: true });
}
