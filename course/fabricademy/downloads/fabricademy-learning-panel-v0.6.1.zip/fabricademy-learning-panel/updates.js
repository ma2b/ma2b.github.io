import { SITE_ROOT } from './model.js';

export const RELEASE_URL = SITE_ROOT + 'data/extension-release.json';
export const UPDATE_CACHE_KEY = 'fabricademy-program-update-v1';
export const UPDATE_MAX_AGE = 24 * 60 * 60 * 1000;
export const UPDATE_RETRY_AGE = 5 * 60 * 1000;

function check(ok) { if (!ok) throw new Error('插件版本信息无效'); }
function parts(version) {
  check(typeof version === 'string' && /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(version));
  const result = version.split('.').map(Number);
  check(result.every(n => n <= 65535));
  return result;
}
export function compareVersions(a, b) {
  const left = parts(a), right = parts(b);
  for (let i = 0; i < 3; i++) if (left[i] !== right[i]) return Math.sign(left[i] - right[i]);
  return 0;
}
export function validateRelease(value) {
  check(value?.schema_version === 1); parts(value.version);
  check(value.download_url === `${SITE_ROOT}downloads/fabricademy-learning-panel-v${value.version}.zip`);
  check(typeof value.sha256 === 'string' && /^[a-f0-9]{64}$/.test(value.sha256));
  check(Array.isArray(value.releases) && value.releases.length > 0 && value.releases.length <= 100);
  let previous;
  const releases = value.releases.map(release => {
    parts(release.version);
    check(typeof release.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(release.date)
      && new Date(release.date).toISOString().slice(0, 10) === release.date);
    check(!previous || (compareVersions(previous.version, release.version) > 0 && previous.date >= release.date));
    check(Array.isArray(release.changes) && release.changes.length > 0 && release.changes.length <= 20);
    check(release.changes.every(line => typeof line === 'string' && line.trim().length > 0 && line.length <= 500));
    previous = release;
    return { version: release.version, date: release.date, changes: [...release.changes] };
  });
  check(releases[0].version === value.version && value.published_at === releases[0].date);
  return { schema_version: 1, version: value.version, published_at: value.published_at,
    download_url: value.download_url, sha256: value.sha256, releases };
}

async function fetchRelease(fetcher) {
  const limit = 128000;
  const response = await fetcher(RELEASE_URL, { credentials: 'omit', cache: 'no-cache', redirect: 'error', signal: AbortSignal.timeout(12000) });
  if (!response.ok) throw new Error('版本网站暂时不可用');
  if (Number(response.headers.get('content-length') || 0) > limit) throw new Error('版本数据过大');
  const reader = response.body.getReader(), chunks = []; let size = 0;
  try {
    while (true) {
      const { value, done } = await reader.read(); if (done) break;
      size += value.length;
      if (size > limit) throw new Error('版本数据过大');
      chunks.push(value);
    }
  } finally { await reader.cancel(); }
  const bytes = new Uint8Array(size); let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  return validateRelease(JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)));
}

// Shared by all extension views through the worker; no page polling or alarms.
export function createUpdateStore(storage, fetcher = fetch, now = Date.now) {
  let record = { release: null, checked_at: 0, failed_at: 0 }, loaded, flight;
  function restore() {
    if (!loaded) loaded = (async () => {
      try {
        const item = (await storage.get(UPDATE_CACHE_KEY))[UPDATE_CACHE_KEY];
        if (!item) return;
        const validTime = value => Number.isFinite(value) && value >= 0 && value <= now();
        if (!validTime(item.checked_at) || !validTime(item.failed_at)) return;
        const release = item.release ? validateRelease(item.release) : null;
        record = { release, checked_at: item.checked_at, failed_at: item.failed_at };
      } catch { /* A damaged cache does not block a fresh check. */ }
    })();
    return loaded;
  }
  const result = () => ({ ...record, ok: !!record.release && !record.failed_at });
  async function checkUpdate(force = false) {
    if (flight) return flight;
    flight = (async () => {
      await restore();
      const time = now();
      if (!force && ((record.failed_at && time - record.failed_at < UPDATE_RETRY_AGE)
          || (!record.failed_at && record.release && time - record.checked_at < UPDATE_MAX_AGE))) return result();
      try {
        const release = await fetchRelease(fetcher);
        // Ignore older deployment snapshots; they must not erase a known update.
        if (record.release && compareVersions(release.version, record.release.version) < 0) throw new Error('版本信息尚未同步');
        const next = { release, checked_at: now(), failed_at: 0 };
        await storage.set({ [UPDATE_CACHE_KEY]: next }); record = next;
      } catch {
        record = { ...record, failed_at: now() };
        try { await storage.set({ [UPDATE_CACHE_KEY]: record }); } catch { /* Keep last good data in memory. */ }
      }
      return result();
    })();
    try { return await flight; } finally { flight = null; }
  }
  return { check: checkUpdate };
}
